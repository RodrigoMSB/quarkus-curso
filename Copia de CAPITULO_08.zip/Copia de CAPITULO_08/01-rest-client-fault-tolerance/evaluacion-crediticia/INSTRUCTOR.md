# 📘 Guía del Instructor - Evaluación Crediticia con Quarkus

---

## 🚀 GUÍA RÁPIDA DE EJECUCIÓN (Para Apuntes del Instructor)

### ✅ Requisitos Previos
- **Java 21** o superior
- **Maven 3.8+**
- **Terminal** con bash (Linux/Mac) o Git Bash (Windows)
- **Python 3** (para el script de pruebas automatizado)

---

### 📋 PASO A PASO PARA EJECUTAR EL EJERCICIO

#### **PASO 1: Posicionarse en el directorio del proyecto**
```bash
cd evaluacion-crediticia
```

#### **PASO 2: Compilar el proyecto**
```bash
./mvnw clean compile
```
**Tiempo estimado:** 30-60 segundos (primera vez descarga dependencias)

---

#### **PASO 3: Levantar el servidor en modo desarrollo**
```bash
./mvnw quarkus:dev
```

**🎯 IMPORTANTE:** 
- Dejar esta terminal corriendo durante toda la sesión
- El servidor estará disponible en: `http://localhost:8080`
- Dev UI de Quarkus: `http://localhost:8080/q/dev`
- Quarkus recargará automáticamente si editas código (hot reload)

**Señales de que está corriendo correctamente:**
```
__  ____  __  _____   ___  __ ____  ______ 
 --/ __ \/ / / / _ | / _ \/ //_/ / / / __/ 
 -/ /_/ / /_/ / __ |/ , _/ ,< / /_/ /\ \   
--\___\_\____/_/ |_/_/|_/_/|_|\____/___/   
...
Listening on: http://localhost:8080
```

---

#### **PASO 4: Abrir NUEVA terminal y ejecutar pruebas**

**4.1 Dar permisos de ejecución al script** (solo la primera vez):
```bash
chmod +x test-evaluacion-crediticia.sh
```

**4.2 Ejecutar el script de pruebas automatizado:**
```bash
./test-evaluacion-crediticia.sh
```

**📝 Nota sobre el script:**
- El script hace **6 pruebas** que demuestran cada patrón de resiliencia
- Tiene **pausas interactivas** entre pruebas (presionar ENTER para continuar)
- Esto permite explicar cada patrón antes de ver el siguiente
- Los resultados se guardan automáticamente en un archivo `.txt` con timestamp

---

### 🧪 LAS 6 PRUEBAS QUE SE EJECUTAN

| # | Patrón | DNI Especial | Qué Demuestra |
|---|--------|--------------|---------------|
| 1 | Happy Path | `11122334456` | Flujo exitoso sin activar patrones |
| 2 | @Retry | `22233445568` | Bureau falla 2 veces, recupera en 3er intento |
| 3 | @Timeout + @Fallback | `33344556678` | Scoring demora 5s, corta en 3s y usa fallback |
| 4 | @Fallback | `44455667788` | Scoring falla, usa scoring básico |
| 5 | @CircuitBreaker | `44455667788` x5 | 5 requests consecutivas, circuito se abre |
| 6 | Validación | `00011223344` | Identidad suspendida, rechazo inmediato |

**💡 REGLA IMPORTANTE:** Los DNIs deben terminar en número **PAR** para tener buen score en Bureau (sin morosidad).

---

### 📊 RESULTADOS ESPERADOS

#### **Prueba 1 - Flujo Exitoso:**
```json
{
  "dni": "11122334456",
  "decision": "APROBADO",
  "scoreTotal": 775,
  "montoAprobado": 30000.0,
  "mensaje": "Crédito aprobado exitosamente"
}
```

#### **Prueba 3 - Timeout + Fallback:**
```json
{
  "dni": "33344556678",
  "decision": "REQUIERE_ANALISIS_MANUAL",
  "scoreTotal": 625,  // ← Score reducido (fallback activado)
  "mensaje": "La solicitud requiere revisión manual por un analista"
}
```
**Tiempo de respuesta:** ~3 segundos (no 5)

#### **Prueba 6 - Identidad Inválida:**
```json
{
  "dni": "00011223344",
  "decision": "RECHAZADO",
  "scoreTotal": 0,
  "motivoRechazo": "Identidad no válida o inactiva",
  "mensaje": "Crédito rechazado: Identidad no válida o inactiva"
}
```

---

### 🔍 QUÉ OBSERVAR EN LOS LOGS DEL SERVIDOR

Durante la ejecución del script, en la terminal donde corre `./mvnw quarkus:dev` verás:

**Prueba 2 - @Retry:**
```
🔴 Bureau: Intento 1 - FALLA (simulando error temporal)
🔴 Bureau: Intento 2 - FALLA (simulando error temporal)
🟢 Bureau: Intento 3 - ÉXITO (después de reintentos)
```

**Prueba 3 - @Timeout:**
```
⏱️  Scoring: DNI 33344556678 - DEMORANDO 5 segundos (timeout en 3s)
```

**Prueba 4 y 5 - @Fallback:**
```
🔴 Scoring: DNI 44455667788 - FALLO permanente (activará fallback)
```

---

### 🛠️ COMANDOS ÚTILES DURANTE LA CLASE

#### **Ver endpoints disponibles:**
```bash
# Mientras el servidor corre, visitar:
http://localhost:8080/q/dev
```

#### **Prueba manual con cURL:**
```bash
curl -X POST "http://localhost:8080/api/evaluacion/credito" \
  -H "Content-Type: application/json" \
  -d '{
    "dni": "11122334456",
    "nombres": "Juan",
    "apellidos": "Perez Lopez",
    "montoSolicitado": 30000,
    "mesesPlazo": 24
  }'
```

#### **Detener el servidor:**
- Presionar `Ctrl + C` en la terminal donde corre `./mvnw quarkus:dev`

#### **Limpiar y recompilar:**
```bash
./mvnw clean compile
```

---

### ⚠️ TROUBLESHOOTING COMÚN

| Problema | Solución |
|----------|----------|
| "Port 8080 already in use" | Detener proceso anterior: `lsof -ti:8080 \| xargs kill -9` (Mac/Linux) |
| "Connection refused" | Verificar que el servidor esté corriendo en otra terminal |
| "No se ve el @Retry" | Observar los logs en la consola donde corre `quarkus:dev` |
| Script no ejecuta | Dar permisos: `chmod +x test-evaluacion-crediticia.sh` |
| Error de Python | Verificar que Python 3 esté instalado: `python3 --version` |

---

### 📝 TIPS PARA LA CLASE VIRTUAL

1. **Pre-ejecutar una vez antes de la clase** para verificar que todo funciona
2. **Compartir pantalla con ambas terminales visibles:**
   - Terminal 1 (arriba): Servidor con logs
   - Terminal 2 (abajo): Script de pruebas
3. **Explicar cada patrón ANTES de presionar ENTER** en el script
4. **Mostrar el código fuente** mientras se ejecuta cada prueba
5. **Archivo de resultados**: Al final, abrir el `.txt` generado para revisar todo el flujo

---

### 🎯 ORDEN SUGERIDO DE EXPLICACIÓN

1. **Arquitectura general** (mostrar diagrama del INSTRUCTOR.md)
2. **REST Client básico** (mostrar interfaces `*Client.java`)
3. **Ejecutar Prueba 1** (Happy Path) → Sin patrones
4. **Explicar @Retry** → Ejecutar Prueba 2
5. **Explicar @Timeout** → Ejecutar Prueba 3
6. **Explicar @Fallback** → Ejecutar Prueba 4
7. **Explicar @CircuitBreaker** → Ejecutar Prueba 5
8. **Mostrar validación early return** → Ejecutar Prueba 6
9. **Resumen final** (usar tabla del script)

**Duración estimada:** 60-90 minutos (con Q&A)

---

## 🎯 Objetivo Pedagógico del Ejercicio

Este ejercicio está diseñado para que los alumnos comprendan **cómo construir microservicios resilientes** que consumen APIs externas de manera robusta. El objetivo NO es solo "hacer que funcione", sino entender **por qué cada patrón existe y qué problema soluciona**.

### ¿Por qué este ejemplo?

**Problema común en arquitecturas de microservicios:**
Imagina que eres un banco y necesitas aprobar un crédito. Para decidir, debes consultar:
- **Bureau de Crédito** (servicio externo, puede estar lento o caído)
- **RENIEC/Identidad** (servicio externo del gobierno)
- **Scoring ML interno** (tu propio servicio, pero puede fallar)

**El desafío:** ¿Qué pasa cuando uno de estos servicios falla? ¿Detenemos todo? ¿Rechazamos al cliente? ¿Esperamos eternamente?

**La solución:** Patrones de resiliencia que permiten que tu microservicio **sobreviva y responda** incluso cuando las cosas salen mal.

---

## 🏗️ Arquitectura General del Ejercicio
```
┌─────────────────────────────────────────────────────┐
│          CLIENTE (Script de Pruebas)                │
└────────────────┬────────────────────────────────────┘
                 │ POST /api/evaluacion/credito
                 ↓
┌─────────────────────────────────────────────────────┐
│    MICROSERVICIO: Evaluación Crediticia (Quarkus)  │
│                                                      │
│  ┌────────────────────────────────────────────┐    │
│  │  EvaluacionResource (REST Endpoint)        │    │
│  │  - Recibe solicitud de crédito             │    │
│  │  - Valida datos (@Valid)                   │    │
│  └──────────────┬─────────────────────────────┘    │
│                 │                                    │
│  ┌──────────────▼─────────────────────────────┐    │
│  │  EvaluacionCrediticiaService               │    │
│  │  - Orquesta llamadas a APIs externas       │    │
│  │  - Aplica patrones de resiliencia          │    │
│  │  - Toma decisión final                     │    │
│  └──┬────────┬────────┬────────────────────────┘   │
│     │        │        │                             │
│     │        │        │ REST Clients (interfaces)   │
│     │        │        │ con @RegisterRestClient     │
│     ↓        ↓        ↓                             │
│  ┌────┐  ┌────┐  ┌──────┐                          │
│  │ IC │  │ BC │  │ SC   │  (Clients)               │
│  └──┬─┘  └──┬─┘  └───┬──┘                          │
└─────┼──────┼────────┼─────────────────────────────┘
      │      │        │
      │      │        │  HTTP Calls
      ↓      ↓        ↓
   ┌────┐ ┌────┐ ┌──────┐
   │ IM │ │ BM │ │ SM   │  (Mocks internos)
   └────┘ └────┘ └──────┘

Leyenda:
IC = IdentidadClient       IM = IdentidadMockResource
BC = BureauCreditoClient   BM = BureauMockResource
SC = ScoringClient         SM = ScoringMockResource
```

**Analogía para explicar:**
Es como hacer un **pastel en 3 pasos**:
1. Comprar ingredientes (validar identidad)
2. Verificar que no estén vencidos (consultar bureau)
3. Cocinar con receta especial (calcular scoring)

Si la tienda está cerrada (servicio caído), ¿qué haces? Los patrones de resiliencia son como tener **planes B, C y D**.

---

## 📦 Librerías y Dependencias Implicadas

### 1. **quarkus-rest** (antes RESTEasy Reactive)
```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-rest</artifactId>
</dependency>
```
**¿Qué hace?** Permite crear endpoints REST (el servidor).
**En este ejercicio:** `EvaluacionResource` expone el endpoint POST para recibir solicitudes.

**Analogía:** Es como la puerta de entrada de un restaurante. Los clientes llegan aquí.

---

### 2. **quarkus-rest-client** + **quarkus-rest-client-jackson**
```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-rest-client</artifactId>
</dependency>
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-rest-client-jackson</artifactId>
</dependency>
```
**¿Qué hace?** Permite consumir APIs REST externas de forma declarativa.
**En este ejercicio:** Los 3 Clients (Bureau, Identidad, Scoring) consumen las APIs mockeadas.

**Clave pedagógica:**
- **rest-client:** Framework base
- **rest-client-jackson:** Serializa/deserializa JSON automáticamente

**Analogía:** Es como tener un mensajero que va a otras tiendas por ti. Solo le dices "tráeme X" y él sabe cómo ir, qué decir y cómo volver.

---

### 3. **quarkus-smallrye-fault-tolerance**
```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-smallrye-fault-tolerance</artifactId>
</dependency>
```
**¿Qué hace?** Implementa patrones de resiliencia (MicroProfile Fault Tolerance).
**En este ejercicio:** Proporciona las anotaciones @Retry, @Timeout, @Fallback, @CircuitBreaker.

**Esta es LA ESTRELLA del ejercicio.** Aquí están los 4 patrones principales.

---

### 4. **quarkus-hibernate-validator**
```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-hibernate-validator</artifactId>
</dependency>
```
**¿Qué hace?** Validación automática de datos con anotaciones.
**En este ejercicio:** Valida que el DNI no esté vacío, que el monto sea positivo, etc.

**Ejemplo:**
```java
@NotBlank(message = "El DNI es obligatorio")
private String dni;
```

---

### 5. **quarkus-rest-jackson**
```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-rest-jackson</artifactId>
</dependency>
```
**¿Qué hace?** Serializa/deserializa JSON para los endpoints REST (el servidor).
**En este ejercicio:** Convierte `SolicitudCredito` de JSON a objeto Java y `ResultadoEvaluacion` de objeto a JSON.

**Diferencia importante para los alumnos:**
- `quarkus-rest-client-jackson`: Para consumir APIs (cliente)
- `quarkus-rest-jackson`: Para exponer APIs (servidor)

---

## 🛡️ Los 4 Patrones de Resiliencia Explicados

### 1. **@Retry - "Intenta de nuevo"**

**Analogía del instructor:**
Imagina que llamas a tu mamá por teléfono y no contesta. ¿Cuelgas y nunca más le hablas? No, esperas 1 minuto y vuelves a llamar. Eso es @Retry.

**Código:**
```java
@Retry(maxRetries = 3, delay = 1, delayUnit = ChronoUnit.SECONDS)
public RespuestaBureau consultarBureau(String dni) {
    return bureauClient.consultarHistorial(dni, bureauApiKey);
}
```

**¿Qué hace?**
- Si la llamada falla, espera 1 segundo y reintenta
- Lo intenta máximo 3 veces
- Si después de 3 intentos sigue fallando, lanza la excepción

**¿Cuándo usarlo?**
- Fallos temporales de red
- Servicios que a veces están sobrecargados
- Timeouts puntuales

**¿Cuándo NO usarlo?**
- Errores de validación (400 Bad Request) → No tiene sentido reintentar
- Errores de autenticación (401) → Reintentar no lo arreglará

**En la prueba:**
DNI `222XXXXX` simula que el Bureau falla 2 veces y responde OK en el 3er intento.

---

### 2. **@Timeout - "No esperes eternamente"**

**Analogía del instructor:**
Vas a un restaurante y pides comida. Si después de 30 minutos no llega, ¿te quedas ahí sentado por 5 horas? No, te vas. Eso es @Timeout.

**Código:**
```java
@Timeout(value = 3, unit = ChronoUnit.SECONDS)
public RespuestaScoring calcularScoring(SolicitudCredito solicitud) {
    return scoringClient.calcularScore(...);
}
```

**¿Qué hace?**
- Si la llamada tarda más de 3 segundos, la corta
- Lanza `TimeoutException`
- Si hay un @Fallback, se activa

**¿Cuándo usarlo?**
- Servicios que pueden colgarse
- Prevenir cascadas de fallos (si esperas 5 min, 100 requests se acumulan)
- Mantener experiencia de usuario aceptable

**Valor recomendado:**
- APIs rápidas: 1-3 segundos
- APIs complejas: 5-10 segundos
- Nunca más de 30 segundos en microservicios

**En la prueba:**
DNI `333XXXXX` simula que el Scoring tarda 5 segundos. El timeout corta en 3 y activa el fallback.

---

### 3. **@Fallback - "Plan B"**

**Analogía del instructor:**
Quieres pizza para la cena, pero la pizzería está cerrada. ¿Te quedas sin cena? No, pides comida china (plan B). Eso es @Fallback.

**Código:**
```java
@Fallback(fallbackMethod = "scoringBasicoFallback")
public RespuestaScoring calcularScoring(SolicitudCredito solicitud) {
    return scoringClient.calcularScore(...);
}

// Método fallback con LA MISMA firma
public RespuestaScoring scoringBasicoFallback(SolicitudCredito solicitud) {
    RespuestaScoring fallback = new RespuestaScoring();
    fallback.setScoreInterno(500); // Score neutral
    fallback.setRecomendacion("REVISAR_MANUAL");
    return fallback;
}
```

**¿Qué hace?**
- Si el método principal falla (por timeout, excepción, etc.), ejecuta el fallback
- El fallback DEBE tener la misma firma que el método original
- El fallback NO debe fallar (debe ser súper simple y confiable)

**Estrategias de fallback:**
1. **Valor por defecto:** Retornar algo neutro (como score 500)
2. **Caché:** Usar un valor guardado anteriormente
3. **Degradación:** Hacer cálculo simplificado (scoring básico vs ML complejo)
4. **Servicio alternativo:** Llamar a otro endpoint

**En la prueba:**
DNI `444XXXXX` hace que el Scoring falle completamente. El fallback retorna score neutral (500) y recomienda análisis manual.

---

### 4. **@CircuitBreaker - "No insistas con lo que no funciona"**

**Analogía del instructor:**
Hay una carretera que SIEMPRE tiene tráfico a las 6pm. ¿Sigues yendo por ahí todos los días esperando que milagrosamente esté libre? No, tomas otra ruta. El Circuit Breaker aprende que el servicio está caído y deja de intentar.

**Estados del Circuit Breaker:**
```
CLOSED (Normal) ──> Fallos acumulados ──> OPEN (Bloqueado) ──> Después de delay ──> HALF_OPEN (Probando) ──> Si funciona ──> CLOSED
                                           ↑                                            ↓
                                           └────────── Si sigue fallando ──────────────┘
```

**Código:**
```java
@CircuitBreaker(
    requestVolumeThreshold = 4,   // Mínimo 4 requests para decidir
    failureRatio = 0.5,            // Si 50% fallan, abre el circuito
    delay = 10,                     // Espera 10 segundos antes de probar de nuevo
    delayUnit = ChronoUnit.SECONDS
)
public RespuestaScoring calcularScoring(SolicitudCredito solicitud) {
    return scoringClient.calcularScore(...);
}
```

**¿Qué hace?**
1. **Estado CLOSED (normal):** Las llamadas pasan normalmente
2. **Detecta fallos:** Si de 4 llamadas, 2 fallan (50%), abre el circuito
3. **Estado OPEN (abierto):** Ni siquiera intenta llamar al servicio, falla inmediatamente
4. **Espera:** Después de 10 segundos, pasa a HALF_OPEN
5. **Estado HALF_OPEN:** Permite 1 llamada de prueba
   - Si funciona → CLOSED (vuelve a normal)
   - Si falla → OPEN (se cierra de nuevo)

**¿Cuándo usarlo?**
- Servicios que pueden caerse por periodos largos
- Prevenir sobrecarga en servicios ya caídos
- Mejorar tiempos de respuesta (no esperar timeout cada vez)

**Combinación poderosa:**
```java
@Retry(maxRetries = 3)
@Timeout(value = 3, unit = ChronoUnit.SECONDS)
@Fallback(fallbackMethod = "scoringBasicoFallback")
@CircuitBreaker(requestVolumeThreshold = 4, failureRatio = 0.5)
public RespuestaScoring calcularScoring(...) {
    // Orden de ejecución:
    // 1. CircuitBreaker verifica si puede pasar
    // 2. Retry intenta hasta 3 veces
    // 3. Timeout limita cada intento a 3 segundos
    // 4. Fallback si todo falla
}
```

**En la prueba:**
DNI `444XXXXX` hace 5 llamadas consecutivas que fallan. El Circuit Breaker debería abrirse, pero como tenemos Fallback, todas responden (el fallback enmascara el fallo).

---

## 🎓 Flujo Completo de una Evaluación Crediticia

### Caso: Solicitud con DNI `11122334456`

**PASO 1: Cliente envía solicitud**
```http
POST /api/evaluacion/credito
{
  "dni": "11122334456",
  "nombres": "Juan",
  "apellidos": "Perez",
  "montoSolicitado": 30000,
  "mesesPlazo": 24
}
```

**PASO 2: `EvaluacionResource` recibe y valida**
```java
public Response evaluarCredito(@Valid SolicitudCredito solicitud)
```
- Hibernate Validator verifica: DNI no vacío, monto > 0, etc.
- Si hay errores de validación → 400 Bad Request

**PASO 3: Llama al Service**
```java
ResultadoEvaluacion resultado = evaluacionService.evaluarSolicitud(solicitud);
```

**PASO 4: Service orquesta las llamadas**

**4.1 Validar Identidad (sin fault tolerance)**
```java
RespuestaIdentidad identidad = validarIdentidad(solicitud.getDni());
```
- Llama a `IdentidadClient` → Mock responde
- Si identidad inválida → Rechaza inmediatamente (fast-fail)

**4.2 Consultar Bureau (@Retry)**
```java
RespuestaBureau bureau = consultarBureau(solicitud.getDni());
```
- Llama a `BureauCreditoClient` → Mock responde
- Si DNI `222XXX` → Falla 2 veces, @Retry reintenta, 3ra vez OK
- Si tiene morosidad → Rechaza

**4.3 Calcular Scoring (@Timeout + @Fallback + @CircuitBreaker)**
```java
RespuestaScoring scoring = calcularScoring(solicitud);
```
- Llama a `ScoringClient` → Mock responde
- Si DNI `333XXX` → Tarda 5s, @Timeout corta en 3s, @Fallback se activa
- Si DNI `444XXX` → Falla, @Fallback se activa
- Circuit Breaker monitorea fallos en segundo plano

**4.4 Evaluar y Decidir**
```java
int scoreTotal = (bureau.getScoreBureau() + scoring.getScoreInterno()) / 2;

if (scoreTotal >= 700 && "APROBAR".equals(scoring.getRecomendacion())) {
    resultado.setDecision("APROBADO");
} else if (scoreTotal < 500) {
    resultado.setDecision("RECHAZADO");
} else {
    resultado.setDecision("REQUIERE_ANALISIS_MANUAL");
}
```

**PASO 5: Retorna resultado al cliente**
```json
{
  "dni": "11122334456",
  "decision": "APROBADO",
  "scoreTotal": 775,
  "montoAprobado": 30000,
  "mensaje": "Crédito aprobado exitosamente"
}
```

---

## 🧪 Las 6 Pruebas Explicadas

### Prueba 1: Happy Path (DNI `111XXXXX` terminado en PAR)
**Objetivo:** Verificar que TODO funciona cuando NO hay problemas.

**Qué pasa:**
- Identidad: ✅ Válida
- Bureau: ✅ Responde rápido (score 750, sin morosidad)
- Scoring: ✅ Responde rápido (score 800)
- Score total: 775 (promedio)
- Decisión: APROBADO

**Punto clave para el instructor:**
"Esta es la línea base. Así debería funcionar el 95% del tiempo en producción. Las siguientes pruebas muestran qué pasa cuando las cosas salen mal."

---

### Prueba 2: @Retry en acción (DNI `222XXXXX`)
**Objetivo:** Ver reintentos automáticos.

**Qué pasa:**
- Identidad: ✅ Válida
- Bureau: 
  - Intento 1: ❌ Falla (503 Service Unavailable)
  - Espera 1 segundo
  - Intento 2: ❌ Falla
  - Espera 1 segundo  
  - Intento 3: ✅ Responde OK
- Scoring: ✅ OK
- Decisión: APROBADO (gracias a @Retry)

**Punto clave para el instructor:**
"Sin @Retry, esta solicitud habría fallado en el primer intento. El cliente habría recibido un error 500. @Retry le dio una segunda y tercera oportunidad al servicio."

**Pedir a los alumnos que observen los logs de Quarkus:**
```
🔴 Bureau: Intento 1 - FALLA (simulando error temporal)
🔴 Bureau: Intento 2 - FALLA (simulando error temporal)
🟢 Bureau: Intento 3 - ÉXITO (después de reintentos)
```

---

### Prueba 3: @Timeout + @Fallback (DNI `333XXXXX`)
**Objetivo:** Ver cómo se protege de servicios lentos.

**Qué pasa:**
- Identidad: ✅ Válida
- Bureau: ✅ OK
- Scoring:
  - Mock intenta dormir 5 segundos
  - @Timeout corta la espera en 3 segundos
  - Lanza TimeoutException
  - @Fallback se activa → Retorna score 500 (neutral)
- Score total: 625 (Bureau 750 + Fallback 500)
- Decisión: REQUIERE_ANALISIS_MANUAL

**Punto clave para el instructor:**
"Nota el tiempo de respuesta: ~3 segundos, NO 5. @Timeout protegió la experiencia del usuario. @Fallback evitó que todo fallara. Sacrificamos precisión (scoring ML) por disponibilidad (scoring básico)."

**Concepto importante:** **Degradación elegante**
- No tenemos el mejor servicio (ML), pero damos un servicio aceptable (básico)
- Es mejor decir "necesita revisión manual" que decir "error 500"

---

### Prueba 4: @Fallback aislado (DNI `444XXXXX`)
**Objetivo:** Ver el fallback cuando el servicio falla completamente.

**Qué pasa:**
- Identidad: ✅ Válida
- Bureau: ✅ OK
- Scoring:
  - Mock retorna 500 Internal Server Error
  - @Fallback se activa inmediatamente
  - Retorna score 500 (neutral)
- Score total: 625
- Decisión: REQUIERE_ANALISIS_MANUAL

**Punto clave para el instructor:**
"Esta es la esencia de la resiliencia: el microservicio NO falló aunque un servicio externo falló. Recuerda: en producción, NO controlas los servicios externos. Pueden caerse en cualquier momento."

---

### Prueba 5: @CircuitBreaker (DNI `444XXXXX` x5)
**Objetivo:** Ver cómo el Circuit Breaker aprende y protege.

**Qué pasa:**
- Se hacen 5 solicitudes consecutivas con el mismo DNI
- Todas fallan en Scoring
- Todas activan @Fallback (por eso responden)
- Circuit Breaker cuenta los fallos
- Después de 4 fallos (50% de 4), el circuito se ABRE
- La 5ta llamada ni siquiera intenta llamar al servicio

**Punto clave para el instructor:**
"¿Por qué no vemos el circuito abierto claramente? Porque @Fallback enmascara el fallo. En producción, el Circuit Breaker evitaría miles de llamadas innecesarias a un servicio caído, ahorrando recursos y mejorando el tiempo de respuesta."

**Para demostrar mejor (opcional):**
Podrías quitar temporalmente el @Fallback y mostrar que después de 4 fallos, la 5ta solicitud falla instantáneamente (no espera timeout).

---

### Prueba 6: Validación de Identidad (DNI `000XXXXX`)
**Objetivo:** Ver rechazo temprano.

**Qué pasa:**
- Identidad: ❌ SUSPENDIDO
- Service rechaza inmediatamente
- NO llama a Bureau ni Scoring
- Decisión: RECHAZADO

**Punto clave para el instructor:**
"Este es el principio de **fail-fast**. ¿Para qué gastar recursos consultando Bureau y Scoring si ya sabemos que la identidad es inválida? Ahorramos 2 llamadas HTTP, tiempo y dinero."

---

## 🎯 Puntos Clave para Enfatizar en Clase

### 1. **Los métodos con fault tolerance DEBEN ser public**
```java
// ❌ MAL - No funciona
@Retry
private RespuestaBureau consultarBureau(String dni) { ... }

// ✅ BIEN
@Retry
public RespuestaBureau consultarBureau(String dni) { ... }
```
**Por qué:** CDI usa interceptores, y los interceptores no pueden aplicarse a métodos privados.

---

### 2. **@RegisterRestClient requiere configuración**
```java
@RegisterRestClient(configKey = "bureau-credito")
public interface BureauCreditoClient { ... }
```

Correspondiente en `application.properties`:
```properties
quarkus.rest-client.bureau-credito.url=http://localhost:8080
```

**Por qué:** Externalización de configuración. En producción, cambiarías la URL sin recompilar.

---

### 3. **Headers personalizados**
```java
RespuestaBureau consultarHistorial(
    @PathParam("dni") String dni,
    @HeaderParam("X-API-Key") String apiKey  // ← Header personalizado
);
```

**En producción:** API Keys, JWT tokens, correlation IDs.

---

### 4. **Orden de ejecución de anotaciones**
```java
@CircuitBreaker  // 1. Primero verifica si puede pasar
@Retry           // 2. Reintenta si falla
@Timeout         // 3. Limita cada reintento
@Fallback        // 4. Si todo falla, usa plan B
```

---

### 5. **Fallback debe ser simple y confiable**
```java
// ❌ MAL - El fallback también puede fallar
public RespuestaScoring scoringBasicoFallback(SolicitudCredito solicitud) {
    return scoringClient.calcularScore(...);  // ← Llamada HTTP!
}

// ✅ BIEN - Cálculo local, sin dependencias
public RespuestaScoring scoringBasicoFallback(SolicitudCredito solicitud) {
    RespuestaScoring fallback = new RespuestaScoring();
    fallback.setScoreInterno(500);
    return fallback;
}
```

---

## 🐛 Troubleshooting Común

### Problema 1: "JSON no se serializa/deserializa"
**Síntoma:** Error 406, o respuestas vacías

**Solución:** Verificar que tengas:
```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-rest-jackson</artifactId>  <!-- Para el servidor -->
</dependency>
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-rest-client-jackson</artifactId>  <!-- Para el cliente -->
</dependency>
```

---

### Problema 2: "Annotations @Retry will have no effect... because the method is private"
**Síntoma:** Error al arrancar Quarkus

**Solución:** Cambiar el método a `public`.

---

### Problema 3: "Circuit Breaker no abre"
**Síntoma:** Todas las solicitudes pasan aunque debería estar abierto

**Diagnóstico:** 
- Verifica `requestVolumeThreshold` (necesita mínimo ese número de requests)
- Verifica `failureRatio` (debe superar ese porcentaje)
- Verifica que NO tengas @Fallback (enmascara fallos)

---

### Problema 4: "Timeout no funciona"
**Síntoma:** El servicio espera más de lo configurado

**Solución:** Verifica que el timeout sea menor que el tiempo de espera del mock.
```java
@Timeout(value = 3, unit = ChronoUnit.SECONDS)  // 3 segundos
```
vs
```java
Thread.sleep(5000);  // Mock duerme 5 segundos - OK
```

---

## 📝 Preguntas Frecuentes de Alumnos

### P: ¿Por qué usar REST Client en lugar de RestTemplate de Spring?
**R:** Porque estamos en Quarkus, no Spring. El equivalente sería:
- Spring: RestTemplate / WebClient
- Quarkus: REST Client (MicroProfile)
  
Además, REST Client es declarativo (solo interfaces), mientras que RestTemplate requiere más código imperativo.

---

### P: ¿Cuándo usar @Retry y cuándo @CircuitBreaker?
**R:** 
- **@Retry:** Fallos temporales puntuales (red intermitente, servicio momentáneamente sobrecargado)
- **@CircuitBreaker:** Fallos sostenidos (servicio caído por 10 minutos, mantenimiento)
- **Juntos:** Lo ideal. @Retry para fallos cortos, Circuit Breaker para fallos largos.

---

### P: ¿Qué pasa si el fallback también falla?
**R:** Ahí sí falla todo y el error se propaga. Por eso el fallback debe ser ULTRA simple (cálculo local, sin llamadas HTTP, sin DB).

---

### P: ¿Por qué algunos métodos tienen fault tolerance y otros no?
**R:** 
- **Sin FT:** `validarIdentidad()` - Debe ser rápido y confiable. Si falla, queremos saberlo inmediatamente.
- **Con FT:** `consultarBureau()`, `calcularScoring()` - Son servicios externos que pueden fallar o ser lentos.

---

### P: ¿El Circuit Breaker se comparte entre todas las solicitudes?
**R:** ¡SÍ! Es global al método. Si el circuito está OPEN, TODAS las solicitudes de TODOS los usuarios fallarán rápido. Eso es intencional para proteger el servicio externo.

---

### P: ¿Qué pasa si llamo al mismo servicio desde dos métodos diferentes?
**R:** Cada método tiene su propio Circuit Breaker independiente. Si quieres compartirlo, debes configurarlo explícitamente.

---

## 🎨 Extensiones Pedagógicas (Tareas/Ejercicios Adicionales)

### Ejercicio 1: Agregar un 4to servicio - Antifraude
Hacer que los alumnos agreguen:
1. `RespuestaAntifraude.java`
2. `AntifrauleClient.java`
3. `AntifrauldMockResource.java`
4. Integrar en el Service con @CircuitBreaker

**Objetivos:**
- Reforzar el patrón de agregar servicios
- Practicar configuración de REST Clients
- Decidir qué patrón aplicar (¿Retry? ¿Timeout?)

---

### Ejercicio 2: Configurar timeouts diferentes por perfil
```properties
# Dev: timeout largo para debugging
%dev.scoring.timeout=30

# Prod: timeout estricto
%prod.scoring.timeout=3
```

**Objetivos:**
- Entender perfiles de Quarkus
- Configuración externalizada

---

### Ejercicio 3: Implementar caché en el fallback
Si el Scoring falla, usar el último score calculado para ese DNI (guardado en un Map en memoria).

**Objetivos:**
- Fallback más inteligente
- Concepto de caché

---

### Ejercicio 4: Métricas con Micrometer
Agregar contadores:
- Cuántas veces se activó el @Retry
- Cuántas veces se activó el @Fallback
- Cuántas veces se abrió el Circuit Breaker

**Objetivos:**
- Observabilidad
- Preparar para Grafana/Prometheus

---

## 📊 Tabla Comparativa de Patrones

| Patrón | Cuándo Usarlo | Analogía | Overhead | Complejidad |
|--------|---------------|----------|----------|-------------|
| **@Retry** | Fallos temporales cortos | Llamar de nuevo si no contestan | Medio | Baja |
| **@Timeout** | Servicios lentos | No esperar eternamente en el restaurante | Bajo | Muy Baja |
| **@Fallback** | Cuando necesitas responder SÍ o SÍ | Plan B si la pizzería está cerrada | Bajo | Media |
| **@CircuitBreaker** | Servicios con caídas largas | No ir por la carretera si SIEMPRE hay tráfico | Medio | Alta |

---

## 🎬 Cierre de la Clase

**Mensaje final para los alumnos:**

"En arquitecturas de microservicios, **fallar es normal**. La red falla, los servicios se caen, las bases de datos se quedan sin conexiones. 

Lo que hace la diferencia entre un sistema amateur y uno profesional NO es que nunca falle, sino **cómo responde cuando falla**.

Los patrones de resiliencia no son opcionales, son **obligatorios** en producción. Netflix, Amazon, Google... todos los usan porque entienden que la pregunta no es '¿Si falla?' sino '**¿Cuándo falla?**'

Con @Retry, @Timeout, @Fallback y @CircuitBreaker, han aprendido a construir sistemas que **sobreviven y responden** incluso cuando todo a su alrededor se está cayendo a pedazos. Eso es resiliencia real."

---

## 📚 Recursos Adicionales para Profundizar

1. **Documentación Oficial:**
   - https://quarkus.io/guides/rest-client
   - https://quarkus.io/guides/smallrye-fault-tolerance

2. **MicroProfile Fault Tolerance Spec:**
   - https://microprofile.io/project/eclipse/microprofile-fault-tolerance

3. **Libro Recomendado:**
   - "Release It!" by Michael Nygard (capítulos sobre Circuit Breaker)

4. **Netflix Hystrix (el OG de Circuit Breakers):**
   - https://github.com/Netflix/Hystrix/wiki

---

## ✅ Checklist de Preparación del Instructor

Antes de dar la clase, verifica:

- [ ] Proyecto compila sin errores
- [ ] Aplicación arranca en dev mode
- [ ] Las 6 pruebas del script funcionan
- [ ] Archivo `instructor.md` leído completo
- [ ] Logs de Quarkus visibles durante las pruebas (para mostrar @Retry)
- [ ] Terminal preparada con colores (para mejor visualización)
- [ ] Script de pruebas con permisos de ejecución
- [ ] Explicar diferencia entre quarkus-rest-jackson vs quarkus-rest-client-jackson
- [ ] Pizarra con diagrama de arquitectura preparado
- [ ] Ejemplos de analogías ensayados

---
