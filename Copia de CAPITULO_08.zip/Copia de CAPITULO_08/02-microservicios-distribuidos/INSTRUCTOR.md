# 📘 Guía del Instructor - Capítulo 8.1: Microservicios Reales

---

## 🚀 GUÍA RÁPIDA DE EJECUCIÓN (Para Apuntes del Instructor)

### ✅ Requisitos Previos
- **Java 21** o superior
- **Maven 3.8+**
- **4 terminales** (una para cada microservicio)
- **Python 3** (para el script de pruebas automatizado)
- **cURL** (para pruebas manuales)

---

### 📋 PASO A PASO PARA EJECUTAR EL EJERCICIO

#### **⚠️ IMPORTANTE: Orden de Ejecución**

Levantar primero los 3 servicios base, al final el orquestador:
1. Bureau Service (8081) ← No depende de nadie
2. Identidad Service (8082) ← No depende de nadie  
3. Scoring Service (8083) ← No depende de nadie
4. Evaluacion Service (8080) ← **ÚLTIMO** (llama a los otros 3)

**Razón:** Si levantas el orquestador primero y haces un request antes que los otros estén listos → Connection refused.

---

### 🖥️ **TERMINAL 1: Bureau Service**

```bash
cd bureau-service
./mvnw clean quarkus:dev
```

**✅ Esperar a ver:**
```
Listening on: http://localhost:8081
```

**Verificar que funciona:**
```bash
curl http://localhost:8081/api/bureau/health
# Debe responder: "Bureau Service OK - Puerto 8081"
```

---

### 🖥️ **TERMINAL 2: Identidad Service**

```bash
cd identidad-service
./mvnw clean quarkus:dev
```

**✅ Esperar a ver:**
```
Listening on: http://localhost:8082
```

**Verificar que funciona:**
```bash
curl http://localhost:8082/api/identidad/health
# Debe responder: "Identidad Service OK - Puerto 8082"
```

---

### 🖥️ **TERMINAL 3: Scoring Service**

```bash
cd scoring-service
./mvnw clean quarkus:dev
```

**✅ Esperar a ver:**
```
Listening on: http://localhost:8083
```

**Verificar que funciona:**
```bash
curl http://localhost:8083/api/scoring/health
# Debe responder: "Scoring Service OK - Puerto 8083"
```

---

### 🖥️ **TERMINAL 4: Evaluacion Service (Orquestador)**

```bash
cd evaluacion-service
./mvnw clean quarkus:dev
```

**✅ Esperar a ver:**
```
Listening on: http://localhost:8080
```

**Verificar que funciona:**
```bash
curl http://localhost:8080/api/evaluacion/health
# Debe responder: "Evaluacion Service OK - Puerto 8080"
```

---

### 🧪 **TERMINAL 5: Ejecutar Script de Pruebas**

```bash
# Dar permisos (solo la primera vez)
chmod +x test-microservicios.sh

# Ejecutar todas las pruebas
./test-microservicios.sh
```

**📝 El script automáticamente:**
1. Verifica que los 4 servicios estén activos (health checks)
2. Si alguno NO responde → ERROR y sale
3. Si todos OK → Ejecuta las 4 pruebas con pausas interactivas

---

### 🧪 LAS 4 PRUEBAS QUE SE EJECUTAN

| # | Descripción | DNI | Resultado Esperado |
|---|-------------|-----|-------------------|
| 1 | Happy Path (comunicación exitosa) | `12345678` (PAR) | APROBADO - Score 775 |
| 2 | Identidad inválida | `00012345` (000) | RECHAZADO - Identidad suspendida |
| 3 | Cliente con morosidad | `12345679` (IMPAR) | RECHAZADO - Morosidad activa |
| 4 | Monto alto | `87654320` (100K) | RECHAZADO - Score insuficiente |

**💡 REGLAS DE NEGOCIO:**
- DNI empieza con "000" → Identidad inválida
- DNI termina en IMPAR → Morosidad activa  
- DNI termina en PAR → Sin morosidad
- Monto > 50,000 → Scoring rechaza

---

### 📊 RESULTADOS ESPERADOS

#### **Prueba 1 - Happy Path:**
```json
{
  "dni": "12345678",
  "decision": "APROBADO",
  "scoreTotal": 775,
  "montoAprobado": 30000.0,
  "mensaje": "Crédito aprobado exitosamente"
}
```
**Cálculo:** (750 bureau + 800 scoring) / 2 = 775

---

#### **Prueba 2 - Identidad Inválida:**
```json
{
  "dni": "00012345",
  "decision": "RECHAZADO",
  "scoreTotal": 0,
  "motivoRechazo": "Identidad no válida o inactiva",
  "mensaje": "Crédito rechazado: Identidad no válida o inactiva"
}
```
**Flujo:** Se detiene en Identidad Service, NO consulta Bureau ni Scoring

---

#### **Prueba 3 - Morosidad:**
```json
{
  "dni": "12345679",
  "decision": "RECHAZADO",
  "scoreTotal": 0,
  "motivoRechazo": "Presenta morosidad activa",
  "mensaje": "Crédito rechazado: Presenta morosidad activa"
}
```
**Flujo:** Pasa Identidad, rechaza en Bureau, NO consulta Scoring

---

#### **Prueba 4 - Monto Alto:**
```json
{
  "dni": "87654320",
  "decision": "RECHAZADO",
  "scoreTotal": 575,
  "motivoRechazo": "Score insuficiente o recomendación negativa",
  "mensaje": "Crédito rechazado"
}
```
**Cálculo:** (750 bureau + 400 scoring) / 2 = 575 < 700 → RECHAZADO

---

### 🔍 QUÉ OBSERVAR EN LOS LOGS (Clave Pedagógica)

Durante la ejecución del script, verás logs **simultáneos** en las 4 terminales:

**Terminal 4 (Evaluacion Service):**
```
🎯 ORQUESTADOR: Iniciando evaluación para DNI 12345678
   → Llamando a Identidad Service...
   → Llamando a Bureau Service...
   → Llamando a Scoring Service...
   ✅ DECISIÓN: APROBADO
```

**Terminal 2 (Identidad Service):**
```
🪪 Identidad Service: Validando DNI 12345678
```

**Terminal 1 (Bureau Service):**
```
🏦 Bureau Service: Consultando DNI 12345678
```

**Terminal 3 (Scoring Service):**
```
🧮 Scoring Service: Calculando para DNI 12345678, Monto: 30000.0
```

**🎓 Punto Pedagógico:** Las 4 terminales se "iluminan" casi simultáneamente, demostrando que son procesos independientes comunicándose por HTTP.

---

### 🛠️ COMANDOS ÚTILES DURANTE LA CLASE

#### **Verificar todos los servicios (health checks):**
```bash
# En una terminal separada:
curl http://localhost:8081/api/bureau/health
curl http://localhost:8082/api/identidad/health
curl http://localhost:8083/api/scoring/health
curl http://localhost:8080/api/evaluacion/health
```

#### **Prueba manual completa (sin script):**
```bash
curl -X POST "http://localhost:8080/api/evaluacion/credito" \
  -H "Content-Type: application/json" \
  -d '{
    "dni": "12345678",
    "nombres": "Juan",
    "apellidos": "Perez Lopez",
    "montoSolicitado": 30000,
    "mesesPlazo": 24
  }'
```

#### **Llamar directamente a un servicio específico:**
```bash
# Bureau Service directamente
curl "http://localhost:8081/api/bureau/consulta/12345678" \
  -H "X-API-Key: BUREAU_API_KEY_12345"

# Identidad Service directamente
curl "http://localhost:8082/api/identidad/validar?dni=12345678" \
  -H "Authorization: Bearer TOKEN_RENIEC_67890"

# Scoring Service directamente
curl -X POST "http://localhost:8083/api/scoring/calcular?dni=12345678&monto=30000&plazo=24"
```

---

### 🛑 CÓMO DETENER TODO AL FINAL DE LA CLASE

#### **Opción 1: Manual (Ctrl+C en cada terminal)**
- Terminal 1: `Ctrl + C`
- Terminal 2: `Ctrl + C`
- Terminal 3: `Ctrl + C`
- Terminal 4: `Ctrl + C`

#### **Opción 2: Matar todos los procesos Java**
```bash
# Mac/Linux
killall java

# O más específico:
pkill -f quarkus
```

#### **Opción 3: Matar por puerto específico**
```bash
# Mac/Linux
lsof -ti:8080 | xargs kill -9
lsof -ti:8081 | xargs kill -9
lsof -ti:8082 | xargs kill -9
lsof -ti:8083 | xargs kill -9
```

---

### ⚠️ TROUBLESHOOTING COMÚN

| Problema | Causa | Solución |
|----------|-------|----------|
| "Connection refused" | Servicios no levantados | Verificar health checks de los 4 servicios |
| "Port already in use" | Puerto ocupado | `lsof -i :8081` y luego `kill -9 <PID>` |
| Script sale inmediatamente | Algún servicio no responde | Revisar cuál falló en el health check |
| No veo logs | Terminal incorrecta | Logs aparecen donde corre `quarkus:dev` |
| Error en Evaluacion Service | Levantado antes que otros | Levantar primero Bureau/Identidad/Scoring |

---

### 📝 TIPS PARA LA CLASE VIRTUAL

1. **Preparación Pre-Clase (15 min antes):**
   - Levantar los 4 servicios
   - Ejecutar script una vez para verificar
   - Dejar las 4 terminales visibles en pantalla

2. **Organización de Pantalla:**
   ```
   ┌─────────────┬─────────────┐
   │  Terminal 1 │  Terminal 2 │
   │  Bureau     │  Identidad  │
   │  (8081)     │  (8082)     │
   ├─────────────┼─────────────┤
   │  Terminal 3 │  Terminal 4 │
   │  Scoring    │  Evaluacion │
   │  (8083)     │  (8080)     │
   └─────────────┴─────────────┘
   ```

3. **Compartir Pantalla:**
   - Mostrar las 4 terminales simultáneamente
   - Cuando ejecutes una solicitud, señalar cómo todas se iluminan
   - Esto es el "wow factor" del ejercicio

4. **Demostración de Fallo (Opcional pero Impactante):**
   - Durante clase: matar el Scoring Service (`Ctrl+C`)
   - Ejecutar solicitud → Error: "Connection refused"
   - **Punto pedagógico:** "Ven? Son servicios REALMENTE independientes"
   - Volver a levantar Scoring → Funciona de nuevo

5. **Orden Sugerido de Explicación:**
   - Mostrar arquitectura (diagrama del README.md)
   - Explicar cada servicio individualmente (1-2 min cada uno)
   - Levantar servicios en orden (Bureau → Identidad → Scoring → Evaluacion)
   - Ejecutar script y explicar cada prueba antes de presionar ENTER
   - Mostrar logs en las 4 terminales (momento clave)
   - Resumen y Q&A

**Duración estimada:** 75-90 minutos (con Q&A)

---

### 🎯 CHECKLIST PRE-CLASE

```
□ Java 21 instalado
□ Maven funcionando
□ 4 terminales preparadas
□ Script tiene permisos de ejecución (chmod +x)
□ Python 3 instalado
□ Puertos 8080-8083 libres
□ Código probado al menos una vez
□ Diagramas listos para compartir
□ Plan B si algo falla (mostrar resultados pre-grabados)
```

---

### 💡 DIFERENCIAS CLAVE CON CAPÍTULO 8

Enfatizar estas diferencias durante la clase:

| Aspecto | Cap 8 (Monolito) | Cap 8.1 (Microservicios) |
|---------|------------------|--------------------------|
| **Proyectos** | 1 proyecto | 4 proyectos independientes |
| **Terminales** | 1 terminal | 4 terminales |
| **Puertos** | 8080 | 8080, 8081, 8082, 8083 |
| **Comunicación** | Llamadas internas (mismo JVM) | HTTP entre servicios (red real) |
| **Despliegue** | Todo junto | Cada servicio por separado |
| **Escalabilidad** | Escala todo | Escala servicios específicos |
| **Fallo** | Falla todo | Solo falla el servicio afectado |

---

## 🎯 Objetivo Pedagógico del Ejercicio

Este ejercicio es **CRÍTICO** porque corrige el problema del Capítulo 8: demostrar una **arquitectura de microservicios REAL**, no un monolito con mocks.

### ¿Por qué este ejercicio es necesario?

**Problema del Capítulo 8:**
- Todos los endpoints en el mismo proyecto
- Mismo puerto (8080)
- Llamadas internas (mismo JVM)
- NO es arquitectura distribuida real

**Solución del Capítulo 8.1:**
- 4 proyectos Quarkus independientes
- 4 puertos diferentes (8080-8083)
- Llamadas HTTP reales entre servicios
- Arquitectura distribuida verdadera

---

## 🏗️ Arquitectura General del Ejercicio

```
CLIENTE (cURL/Postman)
    ↓ HTTP POST
┌─────────────────────────┐
│  Evaluacion Service     │  Puerto 8080
│  (Orquestador)          │
└────┬────────┬───────┬───┘
     │        │       │
     │ HTTP   │ HTTP  │ HTTP
     ↓        ↓       ↓
  ┌─────┐ ┌─────┐ ┌─────┐
  │8082 │ │8081 │ │8083 │
  └─────┘ └─────┘ └─────┘
Identidad Bureau Scoring
```

**Analogía para explicar a los alumnos:**

*"Imagina que estás pidiendo una pizza. NO llamas directamente a la cocina, al repartidor y al cajero. Llamas a UN número (el orquestador) y ellos coordinan internamente con cocina, delivery y pagos. Cada departamento es independiente, tiene su teléfono propio, y puede estar en edificios diferentes."*

---

## 📦 Los 4 Microservicios Explicados

### 1. **Bureau Service** (Puerto 8081)

**Responsabilidad:** Consultar historial crediticio.

**Analogía:** Es como Infocorp/Equifax. Solo hace una cosa: decirte si una persona tiene buen o mal historial de pagos.

**Lógica implementada:**
```java
boolean buenScore = dni.terminaEnPar();
// DNI par = buen score (750, sin morosidad)
// DNI impar = mal score (450, con morosidad)
```

**Endpoints:**
- `GET /api/bureau/consulta/{dni}` - Consulta historial
- `GET /api/bureau/health` - Health check

**Puntos clave para enfatizar:**
- ✅ Es un proyecto COMPLETO e independiente
- ✅ Tiene su propio `pom.xml`
- ✅ Tiene su propio puerto (8081)
- ✅ Puede desplegarse sin los otros servicios
- ✅ En producción, estaría en su propio servidor/contenedor

---

### 2. **Identidad Service** (Puerto 8082)

**Responsabilidad:** Validar identidad (RENIEC/registro civil).

**Analogía:** Es como cuando vas al banco y te piden tu DNI. El cajero verifica que tu DNI sea válido y no esté suspendido.

**Lógica implementada:**
```java
boolean valido = !dni.startsWith("000");
// DNI que empieza con "000" = suspendido
// Otros DNI = válidos
```

**Endpoints:**
- `GET /api/identidad/validar?dni={dni}` - Valida identidad
- `GET /api/identidad/health` - Health check

**Puntos clave para enfatizar:**
- ✅ Usa `@QueryParam` en lugar de `@PathParam`
- ✅ Requiere token de autorización en header
- ✅ Responde ACTIVO/SUSPENDIDO

---

### 3. **Scoring Service** (Puerto 8083)

**Responsabilidad:** Calcular scoring interno (ML/algoritmos).

**Analogía:** Es como el cerebro del banco. Usa algoritmos complejos (en nuestro caso simplificado) para calcular qué tan riesgoso es prestar dinero.

**Lógica implementada:**
```java
boolean aprobado = monto <= 50000;
// Montos bajos = aprueba (score 800)
// Montos altos = rechaza (score 400)
```

**Endpoints:**
- `POST /api/scoring/calcular` - Calcula scoring
- `GET /api/scoring/health` - Health check

**Puntos clave para enfatizar:**
- ✅ Usa `POST` porque recibe parámetros complejos
- ✅ Usa `@QueryParam` para monto y plazo
- ✅ Retorna score + recomendación (APROBAR/RECHAZAR)

---

### 4. **Evaluacion Service** (Puerto 8080 - Orquestador)

**Responsabilidad:** Orquestar todo el proceso y tomar la decisión final.

**Analogía:** Es como el gerente de créditos. Él no valida identidad, no consulta bureau, no calcula scoring. Pero coordina a todos y al final decide: ¿apruebo o rechazo?

**Flujo que ejecuta:**
```
1. Recibe solicitud del cliente
2. → Llama a Identidad Service (8082)
   └─ Si inválida → RECHAZA inmediatamente
3. → Llama a Bureau Service (8081)
   └─ Si morosidad → RECHAZA inmediatamente
4. → Llama a Scoring Service (8083)
   └─ Obtiene score y recomendación
5. → Calcula score total = (Bureau + Scoring) / 2
6. → Decide:
   - Score >= 700 y recomendación APROBAR → APROBADO
   - Score < 500 o recomendación RECHAZAR → RECHAZADO
   - Intermedio → REQUIERE_ANALISIS_MANUAL
```

**Componentes:**
- **3 REST Clients** (interfaces para llamar a los otros servicios)
- **5 Modelos** (DTOs para request/response)
- **1 Service** (lógica de orquestación)
- **1 Resource** (endpoint REST)

**Puntos clave para enfatizar:**
- ✅ Este SÍ usa `@RegisterRestClient`
- ✅ Configura URLs en `application.properties`
- ✅ Hace llamadas HTTP REALES (no internas)
- ✅ Si un servicio externo falla, todo falla (hablaremos de resiliencia después)

---

## 🎓 Flujo Completo de una Solicitud

### Caso: DNI `12345678`, Monto S/ 30,000

**PASO 1: Cliente envía solicitud**
```bash
curl -X POST http://localhost:8080/api/evaluacion/credito -d {...}
```

**PASO 2: EvaluacionResource recibe**
```java
@POST
public Response evaluarCredito(@Valid SolicitudCredito solicitud)
```
- Valida con Hibernate Validator
- Delega al Service

**PASO 3: EvaluacionService orquesta**

**3.1 Valida Identidad**
```java
RespuestaIdentidad identidad = identidadClient.validarIdentidad(dni, token);
```
- HTTP GET a `http://localhost:8082/api/identidad/validar?dni=12345678`
- Identidad Service responde: VÁLIDO, ACTIVO
- ✅ Continúa

**3.2 Consulta Bureau**
```java
RespuestaBureau bureau = bureauClient.consultarHistorial(dni, apiKey);
```
- HTTP GET a `http://localhost:8081/api/bureau/consulta/12345678`
- Bureau Service responde: Score 750, Sin morosidad
- ✅ Continúa

**3.3 Calcula Scoring**
```java
RespuestaScoring scoring = scoringClient.calcularScore(dni, 30000, 24);
```
- HTTP POST a `http://localhost:8083/api/scoring/calcular?dni=12345678&monto=30000&plazo=24`
- Scoring Service responde: Score 800, APROBAR
- ✅ Continúa

**3.4 Evalúa y Decide**
```java
scoreTotal = (750 + 800) / 2 = 775
if (scoreTotal >= 700 && "APROBAR".equals(recomendacion)) {
    decision = "APROBADO"
}
```

**PASO 4: Retorna al cliente**
```json
{
  "dni": "12345678",
  "decision": "APROBADO",
  "scoreTotal": 775,
  "montoAprobado": 30000.0
}
```

---

## 🎭 Demostración en Vivo (Live Coding)

### Preparación Previa a la Clase

1. ✅ Tener los 4 proyectos creados
2. ✅ Tener 4 terminales preparadas (una por servicio)
3. ✅ Script de pruebas listo (`test-microservicios.sh`)
4. ✅ Diagrama de arquitectura en pizarra/slides

### Flujo de Demostración (40 minutos)

#### Parte 1: Mostrar la Arquitectura (5 min)

**Dibujar en pizarra:**
```
┌────────┐
│Cliente │
└───┬────┘
    ↓
┌───────────┐
│  8080     │ Orquestador
└─┬──┬──┬───┘
  ↓  ↓  ↓
8082 8081 8083
```

**Preguntar a los alumnos:**
- *"¿Cuántos proyectos tenemos?"* → 4
- *"¿Cuántos puertos?"* → 4
- *"¿Esto es un monolito?"* → NO

---

#### Parte 2: Levantar los Servicios (10 min)

**Terminal 1 - Bureau Service:**
```bash
cd bureau-service
./mvnw quarkus:dev
```
**Esperar a que levante.** Mostrar el log: `Listening on: http://localhost:8081`

**Explicar:**
*"Este servicio está corriendo COMPLETAMENTE independiente. Si los demás no existen, este sigue funcionando. Miren, voy a llamarlo directamente:"*

```bash
curl "http://localhost:8081/api/bureau/consulta/12345678" \
  -H "X-API-Key: BUREAU_API_KEY_12345"
```

**Mostrar la respuesta.** 

*"Ven? Este servicio NO sabe que existen los otros. Es completamente autónomo."*

**Repetir con Terminal 2 (Identidad) y Terminal 3 (Scoring).**

**Terminal 4 - Evaluacion Service:**
```bash
cd evaluacion-service
./mvnw quarkus:dev
```

**Explicar:**
*"Este es especial. Este SÍ sabe de los otros porque tiene configurado sus URLs en application.properties. Abramos ese archivo..."*

```properties
quarkus.rest-client.bureau-service.url=http://localhost:8081
quarkus.rest-client.identidad-service.url=http://localhost:8082
quarkus.rest-client.scoring-service.url=http://localhost:8083
```

*"Ven? Aquí le estamos diciendo DÓNDE están los otros servicios. En producción, estos serían URLs reales: https://bureau-prod.miempresa.com"*

---

#### Parte 3: Ejecutar Solicitud (15 min)

**Solicitud exitosa:**
```bash
curl -X POST "http://localhost:8080/api/evaluacion/credito" \
  -H "Content-Type: application/json" \
  -d '{
    "dni": "12345678",
    "nombres": "Juan",
    "apellidos": "Perez",
    "montoSolicitado": 30000,
    "mesesPlazo": 24
  }'
```

**INMEDIATAMENTE después de ejecutar, señalar las 4 terminales:**

*"¡Miren! Vean los logs en las 4 terminales:"*

**Terminal 4 (Orquestador):**
```
🎯 ORQUESTADOR: Iniciando evaluación para DNI 12345678
   → Llamando a Identidad Service...
   → Llamando a Bureau Service...
   → Llamando a Scoring Service...
   ✅ DECISIÓN: APROBADO
```

**Terminal 2 (Identidad):**
```
🪪 Identidad Service: Validando DNI 12345678
```

**Terminal 1 (Bureau):**
```
🏦 Bureau Service: Consultando DNI 12345678
```

**Terminal 3 (Scoring):**
```
🧮 Scoring Service: Calculando para DNI 12345678, Monto: 30000.0
```

**Enfatizar:**
*"Esto que acaban de ver es una comunicación HTTP REAL entre 4 servicios independientes. No es código simulado. Son 4 aplicaciones corriendo en 4 puertos, hablándose por HTTP."*

---

#### Parte 4: Demostrar Independencia (10 min)

**Matar el Scoring Service (Ctrl+C en Terminal 3):**

*"Ahora voy a apagar el Scoring Service. Imaginen que se cayó el servidor."*

**Ejecutar la misma solicitud:**
```bash
curl -X POST "http://localhost:8080/api/evaluacion/credito" ...
```

**Resultado:** Error 500

**Explicar:**
*"¿Qué pasó? El orquestador intentó llamar a Scoring, pero no respondió. Todo falló."*

*"Esto es un problema real de microservicios: si un servicio falla, puede afectar a otros. ¿Solución? Patrones de resiliencia como @Retry, @Fallback, @CircuitBreaker que vimos en el Capítulo 8."*

**Levantar de nuevo el Scoring Service.**

*"¿Tuve que reiniciar los otros 3 servicios? NO. Solo reinicié el que falló. Eso es INDEPENDENCIA."*

---

## 🎯 Puntos Clave para Enfatizar

### 1. **Diferencia entre Capítulo 8 y 8.1**

**Capítulo 8:**
```
┌────────────────────────────┐
│  UN SOLO PROYECTO          │
│  Puerto 8080               │
│  ├─ EvaluacionResource     │
│  ├─ BureauMockResource     │  ← Todo en el mismo JVM
│  ├─ IdentidadMockResource  │
│  └─ ScoringMockResource    │
└────────────────────────────┘
```

**Capítulo 8.1:**
```
┌───────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
│ Proyecto 1│  │Proyecto 2│  │Proyecto 3│  │Proyecto 4│
│ Puerto 8080│  │Puerto 8081│ │Puerto 8082│ │Puerto 8083│
└───────────┘  └──────────┘  └──────────┘  └──────────┘
```

**Preguntar:** *"¿Cuál es más realista para producción?"* → Capítulo 8.1

---

### 2. **REST Client vs Llamada Interna**

**Llamada interna (Capítulo 8):**
```java
@Inject
BureauMockResource bureauMock;  // Mismo JVM

RespuestaBureau respuesta = bureauMock.consultarHistorial(dni);
// 0.001 ms - llamada en memoria
```

**REST Client (Capítulo 8.1):**
```java
@Inject @RestClient
BureauClient bureauClient;  // HTTP a otro proceso

RespuestaBureau respuesta = bureauClient.consultarHistorial(dni, apiKey);
// 50-100 ms - llamada HTTP por red
```

**Enfatizar:** *"En microservicios reales, hay latencia de red. Por eso necesitamos caching, @Timeout, etc."*

---

### 3. **Configuración Externalizada**

**Mostrar application.properties del Evaluacion Service:**

```properties
quarkus.rest-client.bureau-service.url=http://localhost:8081
```

**Preguntar:** *"¿Qué pasa si en producción el Bureau Service está en otro servidor?"*

**Respuesta:** Cambias esta línea a:
```properties
%prod.quarkus.rest-client.bureau-service.url=https://bureau-prod.miempresa.com
```

**No recompilas. Solo cambias configuración.**

---

### 4. **Orquestación Centralizada**

**Dibujar en pizarra:**

```
       ORQUESTADOR
           │
    ┌──────┼──────┐
    │      │      │
    1°     2°     3°
    ↓      ↓      ↓
Identidad Bureau Scoring
```

*"El orquestador CONTROLA el flujo. Él decide el orden. Primero Identidad, luego Bureau, luego Scoring. Si cambias el orden, solo cambias código en el orquestador."*

**Alternativa:** Coreografía (eventos)
- Sin orquestador
- Cada servicio reacciona a eventos
- Más desacoplado pero más complejo

---

## 🧪 Las 4 Pruebas Explicadas

### Prueba 1: Happy Path (DNI `12345678`)

**Objetivo:** Verificar que TODO funciona cuando no hay problemas.

**Flujo:**
1. Identidad → VÁLIDO
2. Bureau → Score 750, sin morosidad
3. Scoring → Score 800, APROBAR
4. Decisión → APROBADO (score 775)

**Punto clave:** *"Esta es la línea base. El 90% del tiempo debería ser así."*

---

### Prueba 2: Identidad Inválida (DNI `00012345`)

**Objetivo:** Verificar fail-fast (falla rápido).

**Flujo:**
1. Identidad → SUSPENDIDO
2. ❌ Rechaza INMEDIATAMENTE
3. NO llama a Bureau ni Scoring

**Punto clave:** *"¿Para qué gastar recursos llamando a 2 servicios más si ya sabemos que va a ser rechazado? Esto es EFICIENCIA."*

---

### Prueba 3: Morosidad (DNI `12345679`)

**Objetivo:** Verificar que Bureau detecta problemas.

**Flujo:**
1. Identidad → VÁLIDO
2. Bureau → Morosidad activa
3. ❌ Rechaza
4. NO llama a Scoring

**Punto clave:** *"Decisión tomada en el paso 2. No necesitamos el paso 3."*

---

### Prueba 4: Monto Alto (DNI `87654320`, Monto `100000`)

**Objetivo:** Verificar lógica de negocio del Scoring.

**Flujo:**
1. Identidad → VÁLIDO
2. Bureau → Score 750, sin morosidad
3. Scoring → Score 400, RECHAZAR (monto > 50000)
4. Decisión → RECHAZADO (score 575)

**Punto clave:** *"Aunque Bureau dice OK, Scoring dice NO. Score final no alcanza."*

---

## 🚨 Troubleshooting Común

### Problema 1: "Connection refused"

**Síntoma:**
```
Caused by: java.net.ConnectException: Connection refused
```

**Causa:** Servicio no está levantado.

**Solución:**
```bash
# Verificar qué servicios están corriendo
curl http://localhost:8081/api/bureau/health
curl http://localhost:8082/api/identidad/health
curl http://localhost:8083/api/scoring/health
curl http://localhost:8080/api/evaluacion/health
```

**Enseñar a los alumnos:** *"En microservicios, SIEMPRE verifica que todas las dependencias estén activas."*

---

### Problema 2: "Port already in use"

**Síntoma:**
```
Port 8081 is already in use
```

**Causa:** Ya hay algo corriendo en ese puerto.

**Solución:**
```bash
# Linux/Mac
lsof -i :8081
kill -9 <PID>

# Windows
netstat -ano | findstr :8081
taskkill /PID <PID> /F
```

---

### Problema 3: "Cannot find symbol: RespuestaBureau"

**Causa:** Olvidaste crear el modelo en Evaluacion Service.

**Explicar:** *"Cada servicio necesita sus propios modelos. Bureau Service tiene RespuestaBureau. Evaluacion Service TAMBIÉN necesita su propia copia porque son proyectos separados."*

**Solución:** Crear `RespuestaBureau.java` en el paquete `model` de Evaluacion Service.

---

### Problema 4: REST Client no se inyecta

**Síntoma:**
```
Unsatisfied dependency for type BureauClient
```

**Causa:** Falta `@RegisterRestClient` o falta dependencia en `pom.xml`.

**Solución:**
```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-rest-client</artifactId>
</dependency>
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-rest-client-jackson</artifactId>
</dependency>
```

---

## 📝 Preguntas Frecuentes de Alumnos

### P: ¿Por qué no usar Docker desde el inicio?

**R:** *"Excelente pregunta. Docker agrega otra capa de complejidad. Primero necesitan entender cómo funcionan los microservicios conceptualmente. Una vez que dominen eso, Docker es solo empaquetado. Al final del curso haremos un ejercicio integrador con Docker."*

---

### P: ¿Cómo se llaman entre sí si están en servidores diferentes?

**R:** *"Cambiando la configuración. En lugar de `http://localhost:8081`, pones la URL real:"*

```properties
# Desarrollo (localhost)
%dev.quarkus.rest-client.bureau-service.url=http://localhost:8081

# Producción (servidores reales)
%prod.quarkus.rest-client.bureau-service.url=https://bureau-prod.miempresa.com

# Kubernetes (nombres de servicio)
%k8s.quarkus.rest-client.bureau-service.url=http://bureau-service:8081
```

---

### P: ¿Qué pasa si Bureau Service está en Java y Scoring en Python?

**R:** *"¡Perfecto! Esa es la belleza de microservicios. No importa en qué lenguaje estén. Solo deben exponer una API REST (HTTP + JSON) que otros puedan consumir."*

```
Bureau Service (Java/Quarkus) → HTTP GET → JSON
Scoring Service (Python/Flask) → HTTP POST → JSON
Payment Service (Node.js/Express) → HTTP PUT → JSON
```

*"Todos hablan HTTP + JSON. Es el lenguaje universal."*

---

### P: ¿Cómo manejo transacciones si Bureau aprueba pero Scoring falla?

**R:** *"Esa es LA pregunta del millón en microservicios. Se llama 'transacciones distribuidas'. La solución se llama SAGA Pattern. Lo veremos en el Capítulo 10. Por ahora, sepan que es más complejo que un simple BEGIN TRANSACTION / COMMIT."*

---

### P: ¿No es más lento hacer 3 llamadas HTTP en lugar de 3 llamadas internas?

**R:** *"Sí, absolutamente. Pasamos de 0.003ms (interno) a 200-300ms (HTTP). PERO ganamos:"*
- Escalabilidad (puedo escalar solo Scoring si es el cuello de botella)
- Resiliencia (si Scoring cae, Identidad y Bureau siguen funcionando)
- Equipos autónomos (el equipo de Scoring puede actualizar sin afectar a otros)

*"Es un trade-off: velocidad vs flexibilidad."*

---

## 🎨 Ejercicios Adicionales para los Alumnos

### Ejercicio 1: Agregar Logging de Request ID

**Objetivo:** Agregar un header `X-Request-ID` que se propague por todos los servicios.

**Pistas:**
```java
@HeaderParam("X-Request-ID") String requestId
```

Loggear en cada servicio para rastrear la solicitud completa.

---

### Ejercicio 2: Implementar Cache en Bureau Service

**Objetivo:** Cachear las consultas al Bureau por 5 minutos.

**Pistas:**
```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-cache</artifactId>
</dependency>
```

```java
@CacheResult(cacheName = "bureau-cache")
public RespuestaBureau consultarHistorial(String dni) { ... }
```

---

### Ejercicio 3: Agregar un 5to Microservicio - Notificaciones

**Objetivo:** Crear un Notification Service (Puerto 8084) que reciba notificaciones cuando se aprueba un crédito.

**Estructura:**
```
Evaluacion Service
    ↓ (si APROBADO)
    POST http://localhost:8084/api/notificaciones/enviar
    ↓
Notification Service
    └─ Loggea: "Email enviado a cliente"
```

---

### Ejercicio 4: Implementar Health Checks Avanzados

**Objetivo:** Que el health check de Evaluacion Service verifique si los 3 servicios externos están activos.

**Código:**
```java
@GET
@Path("/health")
public Response health() {
    boolean bureauOk = checkService("http://localhost:8081/api/bureau/health");
    boolean identidadOk = checkService("http://localhost:8082/api/identidad/health");
    boolean scoringOk = checkService("http://localhost:8083/api/scoring/health");
    
    if (bureauOk && identidadOk && scoringOk) {
        return Response.ok("All systems operational").build();
    }
    return Response.status(503).entity("Some services are down").build();
}
```

---

## 📊 Métricas de Éxito de la Clase

Al final de esta clase, los alumnos deben poder:

✅ **Explicar** la diferencia entre monolito y microservicios  
✅ **Crear** un proyecto Quarkus desde cero  
✅ **Configurar** REST Clients con @RegisterRestClient  
✅ **Levantar** múltiples microservicios en diferentes puertos  
✅ **Demostrar** comunicación HTTP entre servicios  
✅ **Identificar** cuándo usar microservicios vs monolito  
✅ **Debuggear** problemas de conexión entre servicios  

---

## 🎬 Cierre de la Clase

**Mensaje final para los alumnos:**

*"Hoy vieron una arquitectura de microservicios REAL. No simulada, no mockeada. 4 aplicaciones independientes hablándose por HTTP.*

*En el Capítulo 8 aprendieron los patrones de resiliencia (@Retry, @CircuitBreaker). En este Capítulo 8.1 vieron POR QUÉ esos patrones son necesarios: porque en microservicios, la red puede fallar, los servicios pueden caer, y TODO debe estar preparado para eso.*

*Microservicios NO son una bala de plata. Introducen complejidad. PERO cuando tu aplicación crece, cuando necesitas escalar, cuando tienes equipos grandes, los microservicios son la arquitectura correcta.*

*Recuerden: Start monolith, evolve to microservices. No empiecen con microservicios si su startup tiene 3 usuarios."*

---

## 📚 Recursos Adicionales

**Libros recomendados:**
- "Building Microservices" by Sam Newman
- "Microservices Patterns" by Chris Richardson

**Videos:**
- Martin Fowler - "Microservices" (YouTube)
- GOTO Conferences - Microservices track

**Blogs:**
- https://microservices.io (Chris Richardson)
- https://martinfowler.com/microservices/

---

## ✅ Checklist del Instructor

Antes de la clase:
- [ ] 4 proyectos compilando sin errores
- [ ] Script de pruebas funcionando
- [ ] Diagrama de arquitectura preparado
- [ ] 4 terminales configuradas
- [ ] Ejemplos de cURL listos
- [ ] Laptop conectada a proyector

Durante la clase:
- [ ] Explicar diferencia con Capítulo 8
- [ ] Levantar servicios de uno en uno
- [ ] Mostrar logs en tiempo real
- [ ] Ejecutar script de pruebas
- [ ] Demostrar fallo de un servicio
- [ ] Responder preguntas

Después de la clase:
- [ ] Compartir código fuente
- [ ] Compartir resultados de pruebas
- [ ] Asignar ejercicios adicionales
- [ ] Preparar soporte para dudas
