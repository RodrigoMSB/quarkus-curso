# 📘 Guía del Instructor - Capítulo 8.2: Microservicios con Docker

---

## 🚀 GUÍA RÁPIDA DE EJECUCIÓN (Para Apuntes del Instructor)

### ✅ Requisitos Previos
- **Docker Desktop** instalado y corriendo
- **Docker Compose** (viene con Docker Desktop)
- **Python 3** (para el script de pruebas automatizado)
- **NO requiere Java instalado** ← Esta es la magia de Docker

---

### 📋 PASO A PASO PARA EJECUTAR EL EJERCICIO

#### **PASO 1: Verificar Docker**

```bash
# Verificar que Docker esté instalado
docker --version
# Debe mostrar: Docker version 20.x o superior

# Verificar que Docker Compose esté disponible
docker-compose --version
# Debe mostrar: Docker Compose version 2.x o superior

# Verificar que Docker esté corriendo
docker ps
# Si da error "Cannot connect to Docker daemon" → Abrir Docker Desktop
```

---

#### **PASO 2: Posicionarse en el directorio del proyecto**
```bash
cd capitulo-8.2-microservicios-docker
```

---

#### **PASO 3: Levantar todos los contenedores con UN SOLO COMANDO**

```bash
docker-compose up --build
```

**🎯 IMPORTANTE:** Este comando hace TODO:
1. Construye las 4 imágenes Docker (tarda 3-5 min la primera vez)
2. Crea la red Docker `microservices-network`
3. Levanta los 4 contenedores
4. Espera a que todos estén "healthy"

**⏳ Tiempos:**
- **Primera ejecución:** 3-5 minutos (descarga imágenes base + compila)
- **Siguientes ejecuciones:** 30 segundos (usa caché)

**✅ Señales de que está listo:**
```
bureau-service      | Listening on: http://0.0.0.0:8081
identidad-service   | Listening on: http://0.0.0.0:8082
scoring-service     | Listening on: http://0.0.0.0:8083
evaluacion-service  | Listening on: http://0.0.0.0:8080
```

**Cuando veas los 4 "Listening on", ya está listo para pruebas.** ✅

---

#### **PASO 4: Abrir NUEVA terminal y verificar contenedores**

```bash
# Ver contenedores corriendo
docker-compose ps
```

**Debe mostrar:**
```
NAME                 COMMAND              STATUS            PORTS
bureau-service       java -jar...         Up (healthy)      0.0.0.0:8081->8081/tcp
identidad-service    java -jar...         Up (healthy)      0.0.0.0:8082->8082/tcp
scoring-service      java -jar...         Up (healthy)      0.0.0.0:8083->8083/tcp
evaluacion-service   java -jar...         Up (healthy)      0.0.0.0:8080->8080/tcp
```

**Todos deben estar "Up (healthy)"** ✅

---

#### **PASO 5: Ejecutar script de pruebas**

```bash
# Dar permisos (solo la primera vez)
chmod +x test-microservicios_docker.sh

# Ejecutar todas las pruebas
./test-microservicios_docker.sh
```

**📝 El script automáticamente:**
1. Verifica que Docker esté instalado
2. Verifica que los 4 contenedores estén corriendo y healthy
3. Ejecuta 4 pruebas con pausas interactivas
4. Guarda resultados en archivo `.txt` con timestamp

---

### 🧪 LAS 4 PRUEBAS QUE SE EJECUTAN

| # | Descripción | DNI | Resultado Esperado |
|---|-------------|-----|-------------------|
| 1 | Happy Path (comunicación entre contenedores) | `12345678` (PAR) | APROBADO - Score 775 |
| 2 | Identidad inválida | `00012345` (000) | RECHAZADO - Identidad suspendida |
| 3 | Cliente con morosidad | `12345679` (IMPAR) | RECHAZADO - Morosidad activa |
| 4 | Monto alto | `87654320` (100K) | RECHAZADO - Score insuficiente |

**💡 MISMAS REGLAS que 8.1, pero ahora en contenedores Docker**

---

### 📊 RESULTADOS ESPERADOS

#### **Prueba 1 - Happy Path:**
```json
{
  "dni": "12345678",
  "decision": "APROBADO",
  "scoreTotal": 775,
  "montoAprobado": 30000.0,
  "mensaje": "Crédito aprobado exitosamente"
}
```

#### **Verificación de Red Docker:**
El script muestra que la comunicación interna funciona:
```
Cliente → evaluacion-service (localhost:8080)
evaluacion-service → identidad-service (http://identidad-service:8082)
evaluacion-service → bureau-service (http://bureau-service:8081)
evaluacion-service → scoring-service (http://scoring-service:8083)
```

**Nota:** Los contenedores se llaman entre sí por **nombre**, no por localhost. Esto es el DNS interno de Docker.

---

### 🔍 QUÉ OBSERVAR EN LOS LOGS

En la terminal donde corre `docker-compose up`, verás logs de los 4 contenedores **mezclados**:

```
bureau-service      | 🏦 Bureau Service: Consultando DNI 12345678
identidad-service   | 🪪 Identidad Service: Validando DNI 12345678
scoring-service     | 🧮 Scoring Service: Calculando para DNI 12345678
evaluacion-service  | 🎯 ORQUESTADOR: Iniciando evaluación para DNI 12345678
```

**🎓 Punto Pedagógico:** Los logs aparecen mezclados porque Docker Compose los consolida. En producción usarías herramientas como Kibana/Grafana para separarlos.

---

### 🛠️ COMANDOS ÚTILES DURANTE LA CLASE

#### **Ver logs de un contenedor específico:**
```bash
# Logs en tiempo real
docker logs -f bureau-service

# Últimas 50 líneas
docker logs --tail 50 bureau-service
```

#### **Entrar a un contenedor (debugging):**
```bash
docker exec -it bureau-service sh

# Dentro del contenedor:
ls -la
cat /app/quarkus-run.jar
exit
```

#### **Ver red Docker:**
```bash
docker network ls
docker network inspect microservices-network
```

#### **Ver imágenes creadas:**
```bash
docker images | grep "capitulo-82"
```

#### **Health check manual:**
```bash
curl http://localhost:8081/api/bureau/health
curl http://localhost:8082/api/identidad/health
curl http://localhost:8083/api/scoring/health
curl http://localhost:8080/api/evaluacion/health
```

#### **Prueba manual completa:**
```bash
curl -X POST "http://localhost:8080/api/evaluacion/credito" \
  -H "Content-Type: application/json" \
  -d '{
    "dni": "12345678",
    "nombres": "Juan",
    "apellidos": "Perez Lopez",
    "montoSolicitado": 30000,
    "mesesPlazo": 24
  }'
```

---

### 🛑 CÓMO DETENER TODO AL FINAL DE LA CLASE

#### **Opción 1: Detener y mantener contenedores**
```bash
# En la terminal donde corre docker-compose
Ctrl + C

# O en otra terminal
docker-compose stop
```

#### **Opción 2: Detener y eliminar contenedores (RECOMENDADO)**
```bash
docker-compose down
```

**¿Qué elimina?**
- ✅ Contenedores
- ✅ Red Docker
- ❌ Imágenes (se mantienen para siguiente ejecución rápida)
- ❌ Volúmenes (no usamos en este ejercicio)

#### **Opción 3: Limpieza completa (elimina TODO)**
```bash
# Detener y eliminar contenedores + red
docker-compose down

# Eliminar las imágenes creadas
docker-compose down --rmi all

# Limpieza total del sistema Docker (CUIDADO)
docker system prune -a --volumes
```

⚠️ **El último comando elimina TODAS las imágenes no usadas, no solo las de este proyecto.**

---

### ⚠️ TROUBLESHOOTING COMÚN

| Problema | Causa | Solución |
|----------|-------|----------|
| "Cannot connect to Docker daemon" | Docker Desktop no está corriendo | Abrir Docker Desktop y esperar a que inicie |
| "port is already allocated" | Puerto 8080-8083 ocupado | `docker-compose down` o `lsof -ti:8080 \| xargs kill -9` |
| "service 'xxx' failed to build" | Error en Dockerfile | Ver logs completos con `docker-compose build bureau-service` |
| Contenedor en "starting" infinito | Health check falla | `docker logs bureau-service` para ver error |
| "No space left on device" | Muchas imágenes acumuladas | `docker system prune -a` |
| Contenedor no "healthy" | Aplicación no responde | `docker logs evaluacion-service` |

---

### 📝 TIPS PARA LA CLASE VIRTUAL

#### **1. Preparación Pre-Clase (15 min antes):**
```bash
# Ejecutar una vez para que todo esté en caché
docker-compose up --build
# Esperar a que todo esté "healthy"
docker-compose down

# Verificar que script funcione
./test-microservicios_docker.sh
```

#### **2. Organización de Pantalla:**
```
┌──────────────────────────────────────┐
│     Terminal 1 (Principal)           │
│     docker-compose up                │
│     (Logs de los 4 contenedores)     │
├──────────────────────────────────────┤
│     Terminal 2 (Comandos/Tests)      │
│     docker-compose ps                │
│     ./test-microservicios_docker.sh  │
└──────────────────────────────────────┘
```

#### **3. Demo Sugerida (Impacto Visual):**
```bash
# Paso 1: Mostrar que NO tienes Java instalado (opcional)
java -version
# "command not found" → Perfecto para el punto

# Paso 2: Levantar TODO con un comando
docker-compose up --build

# Paso 3: Mientras construye, explicar multi-stage build
# "Ven esto? Está descargando Maven, compilando, creando imagen..."

# Paso 4: Nueva terminal, mostrar contenedores
docker-compose ps

# Paso 5: Ejecutar script
./test-microservicios_docker.sh

# Paso 6: Señalar logs mezclados en Terminal 1
# "¿Ven cómo los 4 contenedores escriben logs?"
```

#### **4. Demostración de Escalabilidad (Opcional pero WOW):**
```bash
# Durante la clase:
docker-compose up -d --scale scoring-service=3

# Mostrar
docker-compose ps
# Ahora hay 3 scoring-service corriendo

# Explicar: "En producción, si Scoring recibe mucha carga,
# escalamos horizontalmente. Solo ese servicio."
```

#### **5. Comparación Visual con 8.1:**

**Escribe en pantalla:**
```
CAPÍTULO 8.1                    CAPÍTULO 8.2
4 terminales                →   1 terminal
4 comandos                  →   1 comando
Requiere Java 21            →   NO requiere Java
"Funciona en mi máquina"    →   Funciona en CUALQUIER máquina
```

---

### 🎯 ORDEN SUGERIDO DE EXPLICACIÓN

1. **Contexto (5 min):**
   - Recordar Cap 8.1
   - Problema: "Funciona en mi máquina"
   - Solución: Contenedores

2. **Analogía de Contenedor Marítimo (5 min):**
   - Antes: Cada cosa diferente en el barco
   - Después: Todo en contenedores estándar
   - Igual con software

3. **Dockerfile Explicado (10 min):**
   - Abrir un Dockerfile
   - Explicar multi-stage build
   - Stage 1: BUILD (Maven)
   - Stage 2: RUNTIME (JRE)
   - Resultado: 250MB vs 650MB

4. **docker-compose.yml Explicado (10 min):**
   - services: Los 4 microservicios
   - networks: Red compartida
   - depends_on: Orden de inicio
   - healthcheck: Esperar hasta "healthy"

5. **Demo en Vivo (20 min):**
   - `docker-compose up --build`
   - Mostrar construcción
   - Mostrar logs mezclados
   - Ejecutar script

6. **Comparación con 8.1 (5 min):**
   - Tabla de diferencias
   - Ventajas de Docker

7. **Q&A (5 min)**

**Duración total:** 60-75 minutos

---

### 🎯 CHECKLIST PRE-CLASE

```
□ Docker Desktop instalado y corriendo
□ Proyecto 8.2 descargado
□ Script tiene permisos (chmod +x)
□ Python 3 instalado
□ Ejecutado una vez completo para verificar
□ Puertos 8080-8083 libres
□ Conexión a internet estable (descargas de imágenes)
□ Diagramas listos para compartir
□ docker-compose down ejecutado (empezar limpio)
```

---

### 💡 DIFERENCIAS CLAVE CON CAPÍTULO 8.1

Enfatizar estas diferencias durante la clase:

| Aspecto | Cap 8.1 (Sin Docker) | Cap 8.2 (Con Docker) |
|---------|---------------------|----------------------|
| **Requisitos** | Java 21 + Maven | Solo Docker |
| **Instalación** | Compleja (diferentes OS) | Docker Desktop (uniforme) |
| **Comandos** | 4 terminales, 4 comandos | 1 terminal, 1 comando |
| **Tiempo inicio** | 30 segundos | 3-5 min (1ra vez), 30s (siguientes) |
| **Portabilidad** | "Funciona en mi máquina" | Funciona en CUALQUIER máquina |
| **Aislamiento** | Procesos en mismo OS | Contenedores aislados |
| **Escalabilidad** | Manual | `docker-compose scale` |
| **Producción** | Complejo desplegar | `docker-compose up` en servidor |
| **CI/CD** | Requiere configurar Java/Maven | Solo Docker |
| **Debugging** | Logs en 4 terminales | `docker logs <servicio>` |

---

### 🔥 FRASES CLAVE PARA CLASE

**Para memorizar:**
- *"Docker empaqueta tu aplicación Y todas sus dependencias en una caja."*
- *"Si funciona en Docker, funciona en producción."*
- *"Multi-stage build: Construimos con Maven, ejecutamos con JRE."*
- *"Los contenedores se hablan por nombre, no por localhost."*
- *"Un comando para levantar todo: docker-compose up."*

---

## 🎯 Objetivo Pedagógico del Capítulo

Este capítulo es la **evolución natural del Capítulo 8.1**. Los alumnos ya saben crear microservicios independientes, ahora aprenderán a **contenerizarlos** para producción.

### ¿Por qué este capítulo es crítico?

**Capítulo 8.1 (donde venimos):**
- ✅ 4 proyectos independientes
- ✅ Comunicación HTTP real
- ❌ Requiere Java instalado
- ❌ 4 terminales manuales
- ❌ Difícil de replicar en otros ambientes

**Capítulo 8.2 (dónde estamos):**
- ✅ Arquitectura production-ready
- ✅ NO requiere Java instalado
- ✅ 1 comando para todo
- ✅ Funciona en cualquier máquina con Docker
- ✅ Preparado para Kubernetes (siguiente paso)

---

## 🎓 Conceptos Clave a Transmitir

Al final de esta clase, los alumnos deben poder:

1. ✅ **Explicar qué es Docker** y por qué se usa
2. ✅ **Diferenciar imagen vs contenedor**
3. ✅ **Crear un Dockerfile** con multi-stage build
4. ✅ **Usar Docker Compose** para orquestar servicios
5. ✅ **Entender redes Docker** y DNS interno
6. ✅ **Ejecutar y debuggear** contenedores
7. ✅ **Comparar** desarrollo local vs contenerizado

---

## 📚 Preparación Previa a la Clase

### Requisitos del Instructor

**Software en tu máquina:**
- ✅ Docker Desktop instalado y corriendo
- ✅ Git (para clonar el proyecto)
- ✅ Terminal configurada
- ✅ Editor de código (VS Code recomendado)

**Archivos listos:**
- ✅ Proyecto completo del 8.2
- ✅ Script de pruebas ejecutable
- ✅ Slides con diagramas de arquitectura
- ✅ Comandos de demostración en un archivo de referencia

**Conocimiento previo:**
- ✅ Capítulo 8.1 completado con los alumnos
- ✅ Conceptos básicos de Linux/terminal
- ✅ HTTP y REST

---

## 🎬 Estructura de la Clase (2 horas)

### Módulo 1: Introducción a Docker (20 min)

#### 1.1 El Problema (5 min)

**Empieza con una historia real:**

*"Levanten la mano si alguna vez han escuchado esto: 'Pero en mi máquina funciona'. ¿Sí? Todos. Este es el problema #1 en desarrollo de software."*

**Escribe en la pizarra:**
```
Desarrollador → QA → Staging → Producción
    ✅          ❌       ❌          ❌
```

*"El desarrollador dice que funciona. QA dice que no. Staging tiene errores diferentes. Producción... ni hablemos. ¿Por qué? Porque cada ambiente es DIFERENTE."*

**Escribe las diferencias:**
```
Dev:  Java 21, Ubuntu 22, Port 8080
QA:   Java 17, Ubuntu 20, Port 9080
Prod: Java 21, RedHat 8,  Port 443
```

*"Docker resuelve este problema. ¿Cómo? Empaquetando TODO en un contenedor."*

---

#### 1.2 Analogía del Contenedor de Carga (5 min)

**Dibuja en la pizarra:**

```
ANTES (Sin contenedores marítimos):
┌────────────────────────────┐
│   Barco                    │
│  🍎 📦 🏺 ⚙️             │
│  Cada cosa diferente       │
│  Difícil de apilar         │
│  Lento de cargar           │
└────────────────────────────┘

DESPUÉS (Con contenedores):
┌────────────────────────────┐
│   Barco                    │
│  📦 📦 📦 📦             │
│  Todos iguales            │
│  Fácil de apilar          │
│  Rápido de cargar         │
└────────────────────────────┘
```

*"Docker hizo lo mismo con software. Antes cada aplicación se instalaba diferente. Ahora todo va en contenedores estándares."*

**Pregunta a los alumnos:**
- *"¿Qué ventaja ven en estandarizar?"*
- Respuesta esperada: "Más fácil de mover, apilar, organizar"

---

#### 1.3 Contenedor vs Máquina Virtual (5 min)

**Dibuja la comparación en la pizarra:**

```
MÁQUINA VIRTUAL:
┌──────────────────┐
│ Host OS          │
│ ┌──────────────┐ │
│ │ Hypervisor   │ │
│ │ ┌──────────┐ │ │
│ │ │ Guest OS │ │ │  ← 5 GB
│ │ │   App    │ │ │
│ │ └──────────┘ │ │
│ └──────────────┘ │
└──────────────────┘
Tamaño: GBs
Inicio: Minutos

CONTENEDOR DOCKER:
┌──────────────────┐
│ Host OS          │
│ ┌──────────────┐ │
│ │Docker Engine │ │
│ │ ┌──────────┐ │ │
│ │ │   App    │ │ │  ← 250 MB
│ │ └──────────┘ │ │
│ └──────────────┘ │
└──────────────────┘
Tamaño: MBs
Inicio: Segundos
```

**Analogía:**
*"VM = Casa completa (cimientos, plomería, electricidad)"*  
*"Contenedor = Departamento (comparte infraestructura)"*

---

#### 1.4 Imagen vs Contenedor (5 min)

**Dibuja:**
```
IMAGEN = Molde de galletas 🍪
   ↓ docker run
CONTENEDOR = Galleta (instancia)
```

*"De una imagen puedes crear MUCHOS contenedores. Como de un molde puedes hacer muchas galletas."*

**Demo rápida en terminal:**
```bash
# Mostrar imágenes
docker images

# Mostrar contenedores corriendo
docker ps
```

*"Aquí ven que tenemos 2 imágenes base (maven, eclipse-temurin) y 4 imágenes de nuestros servicios."*

---

### Módulo 2: Dockerfile (30 min)

#### 2.1 Anatomía del Dockerfile (10 min)

**Abre el Dockerfile del bureau-service:**

```dockerfile
FROM maven:3.9-eclipse-temurin-21 AS builder
WORKDIR /build
COPY pom.xml .
RUN mvn dependency:go-offline
COPY src ./src
RUN mvn clean package -DskipTests

FROM eclipse-temurin:21-jre-alpine
WORKDIR /app
COPY --from=builder /build/target/quarkus-app/ ./
EXPOSE 8081
CMD ["java", "-jar", "quarkus-run.jar"]
```

**Explica línea por línea:**

**FROM:**
*"Es como decir: quiero empezar con esta base. Maven con Java 21."*

**WORKDIR:**
*"Es como hacer 'cd /build'. Todo lo siguiente pasa aquí."*

**COPY pom.xml:**
*"¿Por qué copiamos solo pom.xml primero? Para caché. Si solo cambiamos código, no necesita re-descargar deps."*

**RUN mvn dependency:go-offline:**
*"Descarga todas las dependencias. Esta capa se cachea."*

**COPY src:**
*"Ahora sí copiamos el código."*

**RUN mvn package:**
*"Compila la app."*

**Segunda etapa (Multi-Stage):**
*"Aquí empieza lo interesante. Cambiamos a una imagen MÁS PEQUEÑA."*

**COPY --from=builder:**
*"Solo copiamos el JAR compilado. NO copiamos Maven, ni el código fuente. Solo lo necesario."*

**Pregunta a los alumnos:**
- *"¿Por qué no usar una sola etapa?"*
- Respuesta: "Imagen final más pequeña, más segura"

---

#### 2.2 Multi-Stage Build en Profundidad (10 min)

**Dibuja en la pizarra:**

```
ETAPA 1: BUILD
┌─────────────────────┐
│ Maven (50 MB)       │
│ JDK 21 (300 MB)     │
│ Código fuente       │
│ ↓ COMPILA           │
│ app.jar             │
└─────────────────────┘
         │
         │ (Solo copia JAR)
         ↓
ETAPA 2: RUNTIME
┌─────────────────────┐
│ JRE 21 (170 MB)     │  ← MÁS PEQUEÑO
│ app.jar (80 MB)     │
└─────────────────────┘
Imagen final: 250 MB
```

**Comparación:**

| Aspecto | Single-Stage | Multi-Stage |
|---------|-------------|-------------|
| Tamaño | 700 MB | 250 MB |
| Seguridad | Baja (Maven, JDK) | Alta (solo JRE) |
| Velocidad deploy | Lenta | Rápida |

*"En producción, 450 MB menos significa deploy 3x más rápido."*

---

#### 2.3 Demo: Construir una Imagen (10 min)

**En vivo, construye la imagen:**

```bash
cd bureau-service

# Construir
docker build -t bureau-service:latest .
```

**Mientras compila, explica:**

*"Verán 'Step 1/10', 'Step 2/10'... Cada línea del Dockerfile es un 'step'. Docker ejecuta cada uno y crea una capa."*

**Cuando termine:**

```bash
# Ver la imagen creada
docker images bureau-service

# Ver las capas
docker history bureau-service:latest
```

*"Miren: la capa más grande es la de Maven. Por suerte esa NO está en la imagen final gracias a multi-stage."*

---

### Módulo 3: Docker Compose (40 min)

#### 3.1 El Problema de Múltiples Contenedores (5 min)

*"Si tuviéramos que levantar los 4 servicios manualmente, sería así:"*

**Escribe en la pizarra:**
```bash
docker network create mi-red
docker run -d --name bureau --network mi-red -p 8081:8081 bureau-service
docker run -d --name identidad --network mi-red -p 8082:8082 identidad-service
docker run -d --name scoring --network mi-red -p 8083:8083 scoring-service
docker run -d --name evaluacion --network mi-red -p 8080:8080 \
  -e BUREAU_URL=http://bureau:8081 evaluacion-service
```

*"4 comandos largos. Fácil de equivocarse. ¿Solución? Docker Compose."*

---

#### 3.2 Anatomía del docker-compose.yml (15 min)

**Abre el docker-compose.yml y explica sección por sección:**

```yaml
version: '3.8'

services:
  bureau-service:
    build:
      context: ./bureau-service
    ports:
      - "8081:8081"
    networks:
      - microservices-network
    healthcheck:
      test: wget --spider http://localhost:8081/health || exit 1
      interval: 10s
```

**Explica cada parte:**

**services:**
*"Aquí definimos nuestros 4 microservicios."*

**build:**
*"Le decimos: construye la imagen desde este directorio."*

**ports:**
*"Mapeo de puertos. 8081:8081 significa: puerto 8081 del host va al 8081 del contenedor."*

**networks:**
*"Todos en la misma red para que puedan verse."*

**healthcheck:**
*"Docker verifica cada 10 segundos si el servicio está saludable."*

**depends_on:**
*"Evaluacion Service ESPERA a que los otros 3 estén healthy antes de iniciar."*

---

#### 3.3 Demo en Vivo: Levantar Todo (20 min)

**ESTA ES LA PARTE MÁS IMPORTANTE DE LA CLASE**

**Paso 1: Estado inicial**

```bash
# Verificar que no hay nada corriendo
docker ps
```

*"Empezamos de cero."*

---

**Paso 2: El momento de verdad**

```bash
docker-compose up --build
```

*"UN solo comando. Ahora verán la magia."*

**Mientras compila, explica lo que está pasando:**

*"Están viendo 'Building bureau-service', 'Building identidad-service'... Docker está construyendo las 4 imágenes en paralelo."*

*"Miren: 'Downloading maven...' Esto tarda la primera vez. Las siguientes veces será mucho más rápido por el caché."*

**Cuando empiece a levantar:**

*"Ahora ven 'Creating network', 'Creating bureau-service'... Docker crea la red y luego los contenedores."*

**Señala los health checks:**

*"Ven estos mensajes de health check? Docker está esperando que cada servicio responda OK antes de continuar."*

**Cuando aparezcan los 4 "Listening on":**

```
bureau-service      | Listening on: http://0.0.0.0:8081
identidad-service   | Listening on: http://0.0.0.0:8082
scoring-service     | Listening on: http://0.0.0.0:8083
evaluacion-service  | Listening on: http://0.0.0.0:8080
```

*"¡Listo! 4 microservicios corriendo en contenedores Docker. Todo con UN comando."*

---

**Paso 3: Verificar que funcionan**

**Abre OTRA TERMINAL (importante para que vean):**

```bash
# Ver estado
docker-compose ps
```

*"Los 4 contenedores están 'Up (healthy)'. El health check pasó."*

```bash
# Ejecutar prueba
curl -X POST "http://localhost:8080/api/evaluacion/credito" \
  -H "Content-Type: application/json" \
  -d '{
    "dni": "12345678",
    "nombres": "Juan",
    "apellidos": "Perez",
    "montoSolicitado": 30000,
    "mesesPlazo": 24
  }'
```

**INMEDIATAMENTE señala la terminal donde está docker-compose:**

*"¡Miren la terminal de docker-compose! Ven los logs?"*

```
evaluacion-service  | 🎯 Evaluando solicitud...
identidad-service   | 🪪 Validando DNI 12345678
bureau-service      | 🏦 Consultando bureau...
scoring-service     | 🧮 Calculando score...
evaluacion-service  | ✅ APROBADO
```

*"Esto es comunicación REAL entre 4 contenedores Docker a través de HTTP. Cada uno en su propio contenedor aislado."*

---

### Módulo 4: Redes Docker (15 min)

#### 4.1 DNS Interno (10 min)

**Abre application.properties del evaluacion-service:**

```properties
quarkus.rest-client.bureau-service.url=http://bureau-service:8081
```

*"¿Ven esto? NO usa 'localhost'. Usa 'bureau-service'. ¿Por qué?"*

**Dibuja en la pizarra:**

```
Docker Network: microservices-network
├─ bureau-service (172.18.0.2)
├─ identidad-service (172.18.0.3)
├─ scoring-service (172.18.0.4)
└─ evaluacion-service (172.18.0.5)

DNS automático:
bureau-service → 172.18.0.2
```

*"Docker tiene DNS interno. Cuando evaluacion-service llama a 'http://bureau-service:8081', Docker resuelve automáticamente la IP del contenedor."*

**Demo:**

```bash
# Entrar al contenedor evaluacion-service
docker exec -it evaluacion-service sh

# Hacer ping (desde dentro del contenedor)
ping bureau-service
```

*"Ven? Resuelve la IP. Y si detengo y vuelvo a levantar bureau-service, la IP puede cambiar, pero el nombre sigue funcionando."*

---

#### 4.2 Inspeccionar la Red (5 min)

```bash
# Ver las redes
docker network ls

# Inspeccionar nuestra red
docker network inspect microservices-network
```

*"Aquí ven todos los contenedores conectados a esta red, sus IPs, y cómo están aislados del resto del sistema."*

---

### Módulo 5: Comandos Útiles y Troubleshooting (15 min)

#### 5.1 Comandos Esenciales (5 min)

**Escribe en la pizarra los comandos más importantes:**

```bash
# Ver contenedores
docker ps

# Ver logs
docker-compose logs -f evaluacion-service

# Detener todo
docker-compose down

# Reconstruir un servicio
docker-compose build bureau-service

# Escalar
docker-compose up --scale scoring-service=3

# Entrar a un contenedor
docker exec -it bureau-service sh
```

---

#### 5.2 Demo de Troubleshooting (10 min)

**Simula un problema común:**

```bash
# Detén el scoring-service
docker stop scoring-service

# Intenta hacer una solicitud
curl -X POST http://localhost:8080/api/evaluacion/credito ...
```

*"Ven? Falla. ¿Por qué? Porque evaluacion-service no puede contactar a scoring-service."*

**Muestra cómo debuggear:**

```bash
# Ver logs de evaluacion-service
docker-compose logs evaluacion-service

# Verás: "Connection refused to scoring-service"
```

*"En microservicios contenerizados, SIEMPRE verifica los logs de cada servicio. El error puede estar en cualquiera."*

**Levanta el servicio de nuevo:**

```bash
docker start scoring-service

# O con compose:
docker-compose up -d scoring-service
```

*"Ahora funciona. Esta es la ventaja: puedes reiniciar un solo servicio sin afectar a los demás."*

---

## 🎯 Puntos Clave para Enfatizar

### 1. Diferencia entre Capítulo 8.1 y 8.2

**Haz una tabla en la pizarra:**

| Aspecto | 8.1 (Sin Docker) | 8.2 (Con Docker) |
|---------|------------------|------------------|
| Requisitos | Java 21 + Maven | Solo Docker |
| Comandos | 4 terminales | 1 comando |
| Portabilidad | Solo en tu máquina | Cualquier máquina |
| Deploy | Manual | docker-compose up |

*"¿Cuál es más production-ready?"* → 8.2

---

### 2. Por Qué Multi-Stage Build

**Muestra visualmente:**

```
Single-Stage: 700 MB
█████████████████████████████████

Multi-Stage: 250 MB
█████████████

Ahorro: 64%
```

*"En producción, cada MB cuenta. Deploy más rápido, menos tráfico de red, menos costo de almacenamiento."*

---

### 3. Health Checks Son Críticos

*"Sin health check, Docker no sabe si tu app está funcionando. Puede estar corriendo pero respondiendo 500. Health check verifica que REALMENTE esté saludable."*

---

### 4. Docker NO es Solo para Producción

*"Docker también acelera el onboarding de nuevos desarrolladores:"*

```
Sin Docker:
Día 1 del nuevo dev: Instalar Java, Maven, configurar...
Día 2: Todavía configurando...
Día 3: "¿Por qué no me funciona?"

Con Docker:
Día 1: git clone + docker-compose up
Listo en 5 minutos.
```

---

## 🧪 Script de Pruebas Automatizado

**Demuestra el script:**

```bash
chmod +x test-microservicios-docker.sh
./test-microservicios-docker.sh
```

*"Este script verifica:"*
1. ✅ Que Docker esté instalado
2. ✅ Que los 4 contenedores estén corriendo
3. ✅ Que los health checks pasen
4. ✅ Ejecuta 4 casos de prueba
5. ✅ Genera un reporte

*"En CI/CD (continuous integration), este script correría automáticamente en cada commit."*

---

## 🚨 Errores Comunes y Soluciones

### Error 1: "Cannot connect to Docker daemon"

**Síntoma:**
```
Cannot connect to the Docker daemon at unix:///var/run/docker.sock
```

**Causa:** Docker no está corriendo.

**Solución:**
- macOS/Windows: Abrir Docker Desktop
- Linux: `sudo systemctl start docker`

**Enseña a los alumnos:**
*"Antes de cualquier comando Docker, verifica: ¿Docker Desktop está abierto?"*

---

### Error 2: "Port already in use"

**Síntoma:**
```
Error starting userland proxy: bind: address already in use
```

**Causa:** Otro proceso usa el puerto.

**Demo de solución:**

```bash
# Ver qué usa el puerto
lsof -i :8080

# Matar el proceso
kill -9 <PID>
```

*"O cambien el puerto en docker-compose.yml"*

---

### Error 3: Build muy lento

**Síntoma:** Tarda 10+ minutos.

**Explicación:**
*"La primera vez es lento. Docker descarga imágenes base (maven 650 MB, JRE 170 MB) y todas las dependencias Maven. Pero se cachea. La segunda vez: 30 segundos."*

**Demo:**

```bash
# Primera vez
time docker-compose up --build
# → 5 minutos

# Detener
docker-compose down

# Segunda vez
time docker-compose up --build
# → 30 segundos
```

---

### Error 4: Contenedor "unhealthy"

**Síntoma:**
```bash
docker-compose ps
# scoring-service: unhealthy
```

**Causa:** Health check falla.

**Demo de debugging:**

```bash
# Ver logs
docker-compose logs scoring-service

# Probar el endpoint manualmente
curl http://localhost:8083/api/scoring/health
```

*"Si el endpoint no responde, el health check falla. Puede ser que el servicio aún esté iniciando o haya un error."*

---

## 📝 Preguntas Frecuentes de Alumnos

### P: ¿Docker es solo para Linux?

**R:** *"No. Docker Desktop funciona en macOS y Windows. Usa una VM Linux ligera por debajo, pero tú no la ves. Funciona transparente."*

---

### P: ¿Puedo usar Docker en mi proyecto personal?

**R:** *"¡Sí! Docker es gratis para uso personal y pequeñas empresas. Solo pagas si es una empresa grande (>250 empleados)."*

---

### P: ¿Necesito aprender Kubernetes también?

**R:** *"Eventualmente sí, si vas a trabajar en escala grande. Pero Docker y Docker Compose son el fundamento. Primero domina esto."*

---

### P: ¿Por qué no usar Java instalado directamente?

**R:** *"Porque en producción no controlas el servidor. Puede tener Java 17, Java 11, o ninguno. Con Docker, llevas tu propio Java empaquetado."*

---

### P: ¿Docker consume mucha RAM?

**R:** *"Menos que VMs. Cada contenedor usa ~100-300 MB. Los 4 contenedores usan ~1 GB total. Una VM usaría 4-6 GB."*

---

### P: ¿Cómo actualizo un servicio sin afectar a otros?

**R:**
```bash
# Reconstruir solo bureau-service
docker-compose build bureau-service

# Reiniciar solo ese servicio
docker-compose up -d bureau-service
```

*"Los otros 3 siguen corriendo. Cero downtime."*

---

## 🎓 Ejercicios Adicionales para los Alumnos

### Ejercicio 1: Optimizar el Dockerfile

**Objetivo:** Reducir aún más el tamaño de la imagen.

**Pistas:**
- Usar `maven:3.9-eclipse-temurin-21-alpine` (Alpine en build)
- Eliminar archivos innecesarios con `RUN rm -rf`
- Usar `.dockerignore` más agresivo

---

### Ejercicio 2: Agregar Volúmenes para Logs

**Objetivo:** Persistir logs fuera del contenedor.

```yaml
services:
  bureau-service:
    volumes:
      - ./logs:/app/logs
```

*"Ahora los logs sobreviven si eliminas el contenedor."*

---

### Ejercicio 3: Variables de Entorno desde .env

**Objetivo:** Externalizar configuración.

```bash
# .env
BUREAU_URL=http://bureau-service:8081
API_KEY=secret123
```

```yaml
# docker-compose.yml
environment:
  - BUREAU_URL=${BUREAU_URL}
```

---

### Ejercicio 4: Limitar Recursos

**Objetivo:** Evitar que un contenedor consuma todo el CPU/RAM.

```yaml
deploy:
  resources:
    limits:
      cpus: '0.5'
      memory: 512M
    reservations:
      cpus: '0.25'
      memory: 256M
```

---

### Ejercicio 5: Crear un Servicio de Base de Datos

**Objetivo:** Agregar PostgreSQL al docker-compose.

```yaml
services:
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: creditdb
      POSTGRES_USER: admin
      POSTGRES_PASSWORD: secret
    ports:
      - "5432:5432"
    volumes:
      - postgres-data:/var/lib/postgresql/data

volumes:
  postgres-data:
```

---

## 📊 Métricas de Éxito de la Clase

Al final, los alumnos deben poder:

✅ **Explicar** qué es Docker (sin leer)  
✅ **Diferenciar** imagen vs contenedor vs Dockerfile  
✅ **Crear** un Dockerfile con multi-stage build  
✅ **Levantar** los 4 microservicios con `docker-compose up`  
✅ **Debuggear** un contenedor con logs y docker exec  
✅ **Escalar** un servicio con `--scale`  
✅ **Comparar** desarrollo local vs contenerizado  

**Verifica con preguntas:**
- "¿Qué comando para ver contenedores corriendo?" → `docker ps`
- "¿Qué hace COPY --from=builder?" → "Copia de etapa anterior"
- "¿Por qué usar Alpine?" → "Imagen más pequeña"

---

## 🎬 Cierre de la Clase

**Mensaje final para los alumnos:**

*"Hoy vieron Docker aplicado a microservicios. Esto NO es teoría. Esto es exactamente cómo se hace en empresas como Netflix, Uber, Amazon.*

*Aprendieron:*
- ✅ *Qué es Docker y por qué lo necesitan*
- ✅ *Cómo dockerizar una aplicación Quarkus*
- ✅ *Multi-stage builds para optimizar*
- ✅ *Docker Compose para orquestar*
- ✅ *Redes Docker para comunicación*

*En el Capítulo 8.1 tenían microservicios. Ahora en el 8.2 tienen microservicios CONTENERIZADOS y production-ready.*

*Siguiente paso natural: Kubernetes. Pero sin dominar Docker primero, Kubernetes no tiene sentido.*

*Practiquen. Dockericen sus proyectos personales. En 2025, si no sabes Docker, no consigues trabajo en desarrollo cloud."*

---

## ✅ Checklist del Instructor

**Antes de la clase:**
- [ ] Docker Desktop instalado y corriendo
- [ ] Proyecto 8.2 descargado y probado
- [ ] Script de pruebas funcionando
- [ ] Slides con diagramas listos
- [ ] Comandos de demostración en archivo de referencia
- [ ] Terminal configurada (tamaño de fuente grande)
- [ ] Laptop conectada a proyector

**Durante la clase:**
- [ ] Explicar el problema que Docker resuelve
- [ ] Usar analogías (contenedores marítimos, molde de galletas)
- [ ] Diferenciar imagen vs contenedor
- [ ] Explicar Dockerfile línea por línea
- [ ] Demo de docker-compose up en vivo
- [ ] Mostrar logs en tiempo real
- [ ] Demostrar troubleshooting
- [ ] Ejecutar script de pruebas
- [ ] Responder preguntas

**Después de la clase:**
- [ ] Compartir código fuente
- [ ] Compartir comandos útiles (cheat sheet)
- [ ] Asignar ejercicios adicionales
- [ ] Preparar soporte para dudas
- [ ] Recopilar feedback

---

## 📚 Recursos Adicionales

**Para compartir con alumnos:**

**Documentación oficial:**
- https://docs.docker.com/
- https://docs.docker.com/compose/

**Tutoriales interactivos:**
- https://www.docker.com/play-with-docker

**Videos:**
- "Docker in 100 Seconds" - Fireship
- "Docker Crash Course" - TechWorld with Nana

**Libros:**
- "Docker Deep Dive" by Nigel Poulton
- "The Docker Book" by James Turnbull

**Cheat sheets:**
- https://dockerlabs.collabnix.com/docker/cheatsheet/

---

## 🎯 Consejos para la Demostración en Vivo

### DO's ✅

- ✅ **Ensaya antes:** Corre todo al menos 2 veces antes de la clase
- ✅ **Terminal grande:** Fuente 18+ para que todos vean
- ✅ **Explica mientras compila:** No dejes silencios largos
- ✅ **Usa colores:** Syntax highlighting en el código
- ✅ **Señala logs:** Muestra físicamente en la pantalla
- ✅ **Provoca errores:** Muestra cómo debuggear

### DON'Ts ❌

- ❌ **No asumas conocimiento:** Explica cada comando
- ❌ **No vayas rápido:** Docker tarda, usa ese tiempo para explicar
- ❌ **No ignores errores:** Si algo falla, muestra cómo resolverlo
- ❌ **No copies/pegues sin explicar:** Escribe y explica
- ❌ **No saltes el troubleshooting:** Es lo más valioso

---

## 🔥 Momento "WOW" de la Clase

**El momento más impactante debe ser:**

```bash
# Detener todo
docker-compose down

# Levantar todo de nuevo
docker-compose up -d

# Ver que están corriendo en segundos
docker-compose ps

# Hacer una solicitud exitosa
curl http://localhost:8080/api/evaluacion/credito ...
```
