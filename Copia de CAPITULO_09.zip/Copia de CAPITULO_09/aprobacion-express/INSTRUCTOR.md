# 👨‍🏫 INSTRUCTOR.MD - Guía del Profesor

# 👨‍🏫 GUÍA DEL INSTRUCTOR

## 📋 Tabla de Contenidos

1. [Preparación Pre-Clase](#preparación-pre-clase)
2. [Plan de Clase Sugerido](#plan-de-clase-sugerido)
3. [Estrategias de Demostración](#estrategias-de-demostración)
4. [Qué Hacer Si Algo Sale Mal](#qué-hacer-si-algo-sale-mal)
5. [Respuestas a Preguntas Frecuentes](#respuestas-a-preguntas-frecuentes)
6. [Tips de Presentación](#tips-de-presentación)
7. [Ejercicios Opcionales](#ejercicios-opcionales)
8. [Evaluación Sugerida](#evaluación-sugerida)

---

## 🎯 Preparación Pre-Clase

### 24 Horas Antes de la Clase

#### ✅ Checklist Técnico

```bash
# 1. Verificar que PostgreSQL local NO esté corriendo
brew services stop postgresql@16
brew services stop postgresql

# 2. Verificar puertos libres
lsof -i :5432  # Debe estar vacío
lsof -i :8080  # Debe estar vacío

# 3. Limpiar ambiente
docker-compose down -v
rm -rf target/
rm /tmp/build-*.log
rm /tmp/*-run.log

# 4. Levantar PostgreSQL
docker-compose up -d
sleep 10

# 5. Verificar PostgreSQL
docker ps | grep postgres
docker exec banco-postgres psql -U postgres -c "SELECT version();"

# 6. Probar compilación JVM
./mvnw clean package -DskipTests

# 7. Probar que JVM arranca
java -jar target/quarkus-app/quarkus-run.jar &
sleep 5
curl http://localhost:8080/q/health/ready
pkill -f quarkus

# 8. Activar GraalVM (si harás Native)
sdk use java 21.0.1-graalce
java -version  # Verificar que sea GraalVM

# 9. Ejecutar test-aprobacion.sh
./mvnw quarkus:dev &
sleep 10
./test-aprobacion.sh
pkill -f quarkus

# 10. (Opcional) Ejecutar benchmark completo
./benchmark.sh  # Guardar el reporte como referencia
```

**⏱️ Tiempo estimado:** 30-45 minutos

#### 📁 Archivos a Tener Listos

```
proyecto/
├── README.md               ← Abierto en navegador
├── TEORIA.md              ← Abierto en otra pestaña
├── instructor.md          ← Esta guía (impresa o en tablet)
├── test-aprobacion.sh     ← Listo para ejecutar
├── benchmark.sh           ← Listo para ejecutar
├── slides/                ← Presentación con conceptos
│   └── jvm-vs-native.pptx
└── resultados-ejemplo/    ← Resultados pre-ejecutados
    ├── test-report-ejemplo.txt
    └── benchmark-report-ejemplo.txt
```

#### 🖥️ Setup de Pantalla

```
Monitor Principal (Proyector):
┌────────────────────────────────────────┐
│  Terminal (pantalla completa)          │
│  - Fuente grande (16-18pt)             │
│  - Alto contraste                      │
│  - Sin distracciones                   │
└────────────────────────────────────────┘

Monitor Secundario (Tu laptop):
┌────────────────────────────────────────┐
│  [instructor.md] [Notas] [Respaldo]   │
│  - Esta guía                           │
│  - Slides de teoría                    │
│  - Comandos de emergencia              │
└────────────────────────────────────────┘
```

---

## 📚 Plan de Clase Sugerido

### Estructura General (2-3 horas)

#### BLOQUE 1: Introducción y Contexto (15 min)

**Objetivo:** Establecer el problema y la solución.

**Contenido:**
1. Presentación del caso de uso (banco de pre-aprobación crediticia)
2. Requisitos del sistema (respuesta < 200ms, escalabilidad, costos)
3. Por qué Quarkus (cloud-native, containers, serverless)

**Slides sugeridos:**
- Caso de uso bancario
- Requisitos no funcionales
- Comparación: Spring Boot vs Quarkus
- Arquitectura general del sistema

**🎯 Mensaje clave:**
> "Vamos a construir un sistema que debe aprobar créditos en menos de 200ms, escalar automáticamente según demanda, y minimizar costos en cloud. Quarkus está diseñado específicamente para esto."

---

#### BLOQUE 2: Arquitectura del Proyecto (20 min)

**Objetivo:** Entender la estructura antes de ejecutar.

**Contenido:**
1. Tour por el código (5 min)
   - Entities (SolicitudCredito)
   - Services (PreAprobacionService, ScoreCalculator)
   - Resources (REST endpoints)
   - Configuration (application.properties)

2. Conceptos clave (15 min)
   - Hibernate Panache (vs Hibernate tradicional)
   - CDI y @Inject
   - REST + Jackson
   - Health checks y métricas

**🎯 Demo rápida:**
```bash
# Mostrar estructura del proyecto
tree src/main/java -L 3

# Mostrar una entity
cat src/main/java/pe/banco/aprobacion/model/SolicitudCredito.java

# Mostrar un endpoint
cat src/main/java/pe/banco/aprobacion/resource/PreAprobacionResource.java
```

**💡 Tips:**
- No leas todo el código línea por línea
- Enfócate en los patrones y anotaciones
- Menciona que el código está en GitHub para revisar después

---

#### BLOQUE 3: Dev Services (15 min) ⭐ CRÍTICO

**Objetivo:** Entender la "magia" de Quarkus en desarrollo.

**Contenido:**
1. ¿Qué son Dev Services? (concepto)
2. Por qué es revolucionario
3. Demo en vivo

**🎯 Demo:**
```bash
# Antes de ejecutar, mostrar application.properties
cat src/main/resources/application.properties | grep datasource

# Explicar: "Miren, NO hay URL de base de datos configurada"
# "Entonces... ¿cómo va a funcionar? 🤔"

# Ejecutar
./mvnw quarkus:dev

# Mientras arranca, explicar:
# "Quarkus detectó que necesitamos PostgreSQL"
# "Está levantando un contenedor Docker automáticamente"
# "Esto solo pasa en modo dev"

# Cuando arranque (1-2 min)
# Mostrar en Docker Desktop: contenedor efímero creado

# Probar endpoint
curl http://localhost:8080/q/health/ready
curl http://localhost:8080/api/preaprobacion/estadisticas

# Explicar: "Cuando detengo la app, el contenedor desaparece"
# Ctrl+C

# Verificar que el contenedor se fue
docker ps
```

**🎯 Mensaje clave:**
> "Dev Services es como tener un asistente que prepara tu ambiente automáticamente. Cero configuración, cero instalaciones manuales. Esto acelera el desarrollo 10x."

**⚠️ Advertencia para alumnos:**
"Esto SOLO funciona en modo dev. En producción usamos docker-compose o bases de datos reales."

---

#### BLOQUE 4: Tests Funcionales (20 min)

**Objetivo:** Demostrar testing automatizado.

**Contenido:**
1. Introducción al script test-aprobacion.sh
2. Qué prueba (health, métricas, CRUD, validaciones)
3. Ejecución en vivo

**🎯 Demo:**
```bash
# Terminal 1: Iniciar app
./mvnw quarkus:dev

# Esperar que arranque (mostrar logs)

# Terminal 2: Ejecutar tests
./test-aprobacion.sh

# Mientras corre (2-3 min), explicar:
# - 13 pruebas funcionales
# - Casos de aprobación vs rechazo
# - Validaciones de negocio
# - Generación de reporte

# Cuando termine, mostrar:
cat test-report-*.txt | grep -A 10 "RESULTADOS FINALES"

# Destacar: 13/13 pasadas ✅
```

**💡 Tips:**
- Deja que el script corra mientras explicas conceptos
- Cuando llegue a la parte de "Cliente en lista negra", explica las reglas de negocio
- Muestra el reporte .txt generado

**🎯 Mensaje clave:**
> "En un proyecto real, estos tests se ejecutan en CI/CD antes de cada deploy. Si algo falla, no pasa a producción."

---

#### BLOQUE 5: JVM vs Native - Teoría (20 min)

**Objetivo:** Entender las diferencias fundamentales.

**Contenido:** (Usar slides aquí)

1. **Arquitectura JVM** (5 min)
   - JVM + Bytecode + JIT
   - Ventajas: portabilidad, optimizaciones runtime
   - Desventajas: arranque lento, memoria alta

2. **Arquitectura Native** (5 min)
   - GraalVM + AOT compilation
   - Ventajas: arranque rápido, memoria baja
   - Desventajas: compilación lenta, menos portable

3. **Tabla comparativa** (5 min)
   - Mostrar la tabla del benchmark
   - Explicar cada métrica

4. **Casos de uso** (5 min)
   - Cuándo JVM
   - Cuándo Native
   - Ejemplos reales

**📊 Slides sugeridos:**
```
Slide 1: Arquitectura JVM (diagrama)
Slide 2: Arquitectura Native (diagrama)
Slide 3: Tabla comparativa (métricas)
Slide 4: Casos de uso (matriz decisión)
Slide 5: GraalVM - Cómo funciona (proceso)
```

**🎯 Analogía útil:**
> "JVM es como tener un intérprete simultáneo en una conferencia. Es flexible y se adapta sobre la marcha, pero necesita tiempo para 'calentar'."
>
> "Native es como tener el discurso PRE-TRADUCIDO. Arranque instantáneo, pero si cambias el idioma, tienes que re-traducir todo."

---

#### BLOQUE 6: Benchmark JVM vs Native (45 min) ⭐ ESTRELLA

**Objetivo:** Ver las diferencias en acción.

**⚠️ DECISIÓN CRÍTICA:** ¿Ejecutar en vivo o mostrar pre-grabado?

##### OPCIÓN A: Ejecución en Vivo (si tienes tiempo y confianza)

```bash
# Antes de comenzar
./benchmark.sh

# Explicar mientras compila:
# Fase 1-2: JVM (rápido, 2-3 min)
# Fase 3: Native (LENTO, 8-10 min) ← AQUÍ explicas teoría

# Durante la compilación Native:
# - Mostrar slides de GraalVM
# - Explicar proceso de compilación AOT
# - Responder preguntas
# - Mostrar el log de compilación en otra terminal
```

**⏱️ Timing:**
- Compilación JVM: 10 seg → Explicar qué hace
- Pruebas JVM: 2 min → Mostrar arranque, memoria
- **Compilación Native: 8-10 min** → AQUÍ das la teoría profunda
- Pruebas Native: 2 min → Comparar resultados
- Análisis: 5 min → Conclusiones

**💡 Tips para mantener la atención durante compilación Native:**
1. Muestra el log en tiempo real (es fascinante ver las fases)
2. Explica cada fase (Analysis, Universe, Compilation, etc.)
3. Abre slides paralelos sobre GraalVM
4. Cuenta casos de uso reales (Netflix, Amazon, etc.)
5. Responde preguntas de los alumnos

##### OPCIÓN B: Mostrar Resultados Pre-ejecutados (más seguro)

```bash
# Mostrar reporte guardado
cat benchmark-report-2025-10-23-135503.txt

# Explicar cada sección:
# 1. Tiempo de compilación
# 2. Tiempo de arranque
# 3. Memoria
# 4. Throughput
# 5. Conclusiones

# Ejecutar SOLO Native manual (para demostrar arranque)
./target/aprobacion-express-1.0.0-runner &

# Cronometrar arranque (< 1 segundo)
time curl http://localhost:8080/q/health/ready

pkill -f aprobacion
```

**🎯 Recomendación:** **OPCIÓN B** para clases regulares, OPCIÓN A solo si:
- Ya lo probaste ese mismo día
- Tienes tiempo extra (clase de 3+ horas)
- Hay un plan B preparado

---

#### BLOQUE 7: Análisis de Resultados (15 min)

**Objetivo:** Interpretar el benchmark.

**Contenido:**
1. Mostrar tabla de resultados
2. Analizar cada métrica
3. Calcular ROI en cloud
4. Casos de uso reales

**🎯 Análisis guiado:**

```
╔══════════════════════════════════════════════════════════════╗
║ MÉTRICA            │  JVM      │  NATIVE   │  DIFERENCIA    ║
╠══════════════════════════════════════════════════════════════╣
║ Compilación        │  7s       │  96s      │  JVM 13.7x +   ║
║ Arranque           │  2s       │  2s       │  Empate        ║
║ Memoria            │  245 MB   │  68 MB    │  Native 72% -  ║
║ Throughput         │  33 req/s │  50 req/s │  Native 50% +  ║
╚══════════════════════════════════════════════════════════════╝
```

**Explicación por métrica:**

**1. Compilación:**
> "JVM es 13x más rápido compilando. ¿Importa? Solo en desarrollo. En producción compilas UNA vez."

**2. Arranque:**
> "En este benchmark son similares porque la app es pequeña. En apps grandes, Native puede ser 20-40x más rápido."

**3. Memoria (⭐ MÁS IMPORTANTE):**
> "Native usa 72% menos memoria. En Kubernetes con 100 pods:
> - JVM: 100 pods × 245 MB = 24.5 GB
> - Native: 100 pods × 68 MB = 6.8 GB
> - Ahorro: 17.7 GB de RAM
> - En AWS/GCP: Ahorro de ~$200-500/mes POR SERVICIO"

**4. Throughput:**
> "Native tiene 50% más throughput. Esto significa:
> - Menos pods necesarios para la misma carga
> - Menor latencia p99
> - Mejor experiencia de usuario"

**💰 Cálculo de ROI:**
```
Escenario: Microservicio en AWS ECS/Fargate

JVM:
- Pods: 10 (para manejar carga)
- Memoria por pod: 512 MB (para 245 MB real)
- Costo: $0.04 por GB-hora
- Costo mensual: 10 × 0.5 GB × $0.04 × 730h = $146/mes

Native:
- Pods: 7 (menos necesarios por mejor throughput)
- Memoria por pod: 256 MB (para 68 MB real)
- Costo: $0.04 por GB-hora
- Costo mensual: 7 × 0.25 GB × $0.04 × 730h = $51/mes

AHORRO: $95/mes por servicio (65% menos)
Con 10 microservicios: $950/mes = $11,400/año
```

**🎯 Mensaje clave:**
> "Native no es solo 'más rápido'. Es significativamente más barato en cloud. En una arquitectura de microservicios, el ahorro puede ser de decenas de miles de dólares al año."

---

#### BLOQUE 8: Profundizando en Configuración (10 min)

**Objetivo:** Mostrar perfiles y configuración avanzada.

**Contenido:**
1. Perfiles de Quarkus (%dev, %test, %prod)
2. Variables de entorno
3. ConfigMaps en Kubernetes

**🎯 Demo:**
```bash
# Mostrar application.properties
cat src/main/resources/application.properties

# Destacar:
# - Configuración base
# - %dev prefix
# - %prod prefix con variables de entorno

# Explicar:
# "En dev: usa Dev Services automático"
# "En prod: usa variables de entorno del cluster"
```

---

#### BLOQUE 9: Docker y Contenedores (15 min)

**Objetivo:** Preparar para despliegue.

**Contenido:**
1. Por qué necesitamos docker-compose (vs Dev Services)
2. Crear Dockerfile (opcional)
3. Deploy en Kubernetes (slides)

**🎯 Demo:**
```bash
# Mostrar docker-compose.yml
cat docker-compose.yml

# Explicar diferencias con Dev Services

# (Opcional) Construir imagen Docker
docker build -f src/main/docker/Dockerfile.native -t banco-app:1.0 .
docker run -p 8080:8080 banco-app:1.0
```

---

#### BLOQUE 10: Q&A y Cierre (15 min)

**Objetivo:** Consolidar aprendizaje.

**Contenido:**
1. Responder preguntas
2. Recapitular puntos clave
3. Entregar material adicional

**🎯 Recapitulación:**
```
✅ Quarkus optimizado para cloud y containers
✅ Dev Services acelera desarrollo 10x
✅ Native reduce memoria 60-70%
✅ Ahorro significativo de costos en producción
✅ JVM para desarrollo, Native para producción
```

**📦 Material para llevar:**
- README.md (setup completo)
- TEORIA.md (conceptos profundos)
- Link a GitHub del proyecto
- Slides en PDF

---

## 🎭 Estrategias de Demostración

### Regla de Oro: KISS (Keep It Simple, Stupid)

**✅ HACER:**
- Mantener la terminal limpia (clear frecuentemente)
- Fuente grande y legible
- Narrar lo que haces ANTES de hacerlo
- Pausas para que copien comandos
- Verificar que funciona antes de continuar

**❌ NO HACER:**
- Cambiar entre 10 ventanas
- Teclear rápido sin explicar
- Asumir que todos siguen al mismo ritmo
- Improvisar comandos complejos
- Ignorar errores esperando que nadie los vea

### Técnica del "Narrador Deportivo"

```bash
# MAL (silencio incómodo mientras tipeas)
./mvnw quarkus:dev

# BIEN (narras mientras tipeas)
# "Voy a iniciar la aplicación en modo desarrollo..."
./mvnw quarkus:dev
# "Fíjense que estoy usando ./mvnw, que es el Maven Wrapper"
# "Esto garantiza que todos usemos la misma versión de Maven"
# "Y el comando quarkus:dev activa el modo de desarrollo con Dev Services"
```

### Técnica del "Checkpoint"

Después de cada demo importante:
```
🔍 Checkpoint: "¿Todos vieron cómo arrancó en 1 segundo?"
🔍 Checkpoint: "¿Alguien tiene dudas hasta aquí?"
🔍 Checkpoint: "Levanten la mano si les funcionó"
```

### Manejo de Errores en Vivo

**Si algo falla durante la demo:**

1. **Respira y sonríe** 😊
2. **Reconoce el error** (no lo ignores)
3. **Usa el Plan B** (ver siguiente sección)

**Frases útiles:**
> "Interesante, esto no pasó en el ensayo. Perfecto, porque así vemos troubleshooting en vivo."
>
> "Este es exactamente el tipo de error que encontrarán en el mundo real. Veamos cómo resolverlo."
>
> "Tengo un resultado pre-ejecutado aquí. Sigamos con eso mientras debugging esto en el break."

---

## 🆘 Qué Hacer Si Algo Sale Mal

### Plan B - Jerarquía de Respaldo

```
Nivel 1: Fix rápido (< 1 min)
   ↓
Nivel 2: Usar resultado pre-ejecutado
   ↓
Nivel 3: Skip demo, explicar con slides
   ↓
Nivel 4: Break temprano para debugging
```

### Problemas Comunes y Soluciones

#### PROBLEMA 1: "Port 8080 already in use"

**Síntomas:**
```
Port 8080 required by Quarkus is already in use
```

**Fix rápido:**
```bash
# Matar proceso en puerto 8080
lsof -ti:8080 | xargs kill -9

# O cambiar puerto
./mvnw quarkus:dev -Dquarkus.http.port=8081
```

**Tiempo:** 30 segundos

---

#### PROBLEMA 2: PostgreSQL no arranca

**Síntomas:**
```
Failed to connect to localhost:5432
role "postgres" does not exist
```

**Fix rápido:**
```bash
# Resetear PostgreSQL
docker-compose down -v
sleep 2
docker-compose up -d
sleep 10
```

**Tiempo:** 30 segundos

**Si sigue fallando:**
> "Tengo Dev Services como respaldo, que no necesita docker-compose. Vamos con eso."

```bash
# Detener todo
docker-compose down

# Usar Dev Services
./mvnw quarkus:dev
```

---

#### PROBLEMA 3: Benchmark se cuelga

**Síntomas:**
El benchmark no avanza o falla en medio.

**Plan B inmediato:**
```bash
# Ctrl+C para cancelar

# Mostrar reporte pre-ejecutado
cat benchmark-report-2025-10-23-135503.txt

# Explicar:
# "Este es un reporte que ejecuté esta mañana"
# "Los resultados son representativos"
```

**Tiempo:** 10 segundos

---

#### PROBLEMA 4: GraalVM no está instalado

**Síntomas:**
```
Cannot find native-image in GRAALVM_HOME
```

**Plan B inmediato:**
```bash
# Usar Docker para compilar (genera binario Linux)
./mvnw package -Pnative -DskipTests -Dquarkus.native.container-build=true

# Explicar limitación:
# "Este binario es para Linux, no correrá en mi Mac"
# "Pero el proceso es el mismo"
# "En CI/CD usaríamos exactamente esto"
```

**Tiempo:** Explicar + compilar (10 min)

**Mejor opción:**
> "Por tiempo, voy a mostrar el resultado pre-ejecutado del benchmark Native."

---

#### PROBLEMA 5: Internet lento (descarga de dependencias)

**Síntomas:**
Maven descargando dependencias muy lento.

**Plan B:**
```bash
# Usar cache local (si pre-descargaste)
./mvnw -o package  # Offline mode

# O postponer la demo
# "Mientras Maven descarga dependencias, 
#  veamos la teoría de GraalVM con slides"
```

---

### Comandos de Emergencia

Tener estos en un archivo `emergency.sh`:

```bash
#!/bin/bash
# emergency.sh - Comandos de emergencia para la clase

echo "=== RESETEO COMPLETO ==="

# 1. Matar todos los procesos Java
pkill -9 java

# 2. Detener Docker
docker-compose down -v
docker stop $(docker ps -aq) 2>/dev/null

# 3. Liberar puertos
lsof -ti:8080 | xargs kill -9 2>/dev/null
lsof -ti:5432 | xargs kill -9 2>/dev/null

# 4. Limpiar builds
./mvnw clean

# 5. Limpiar logs
rm /tmp/build-*.log
rm /tmp/*-run.log

# 6. Reiniciar PostgreSQL
docker-compose up -d
sleep 10

echo "=== LISTO ==="
echo "Intenta de nuevo con: ./mvnw quarkus:dev"
```

**Uso:**
```bash
chmod +x emergency.sh
./emergency.sh
```

---

## ❓ Respuestas a Preguntas Frecuentes

### "¿Por qué no usamos Spring Boot?"

**Respuesta:**
> "Spring Boot es excelente y maduro. Pero fue diseñado antes de la era cloud-native. Quarkus fue construido desde cero para contenedores, Kubernetes y GraalVM Native. Puedes hacer Native con Spring, pero Quarkus lo hace mejor porque fue su diseño original."

**Datos:**
- Spring Boot Native arranque: ~0.5-1 seg
- Quarkus Native arranque: ~0.05-0.2 seg
- Spring Native aún en preview (3.x)
- Quarkus Native production-ready desde 1.x

---

### "¿Vale la pena el tiempo extra de compilación Native?"

**Respuesta:**
> "Sí, si despliegas en cloud. Compilas una vez (en CI/CD), pero ahorras costos cada minuto que está corriendo. El ROI es positivo después del primer mes."

**Cálculo rápido:**
```
Compilación Native extra: 2 minutos
Deploys por mes: 100 (varios al día en CI/CD)
Tiempo extra total: 200 minutos = 3.3 horas/mes

Ahorro en cloud: $100-500/mes
Costo de CI/CD: ~$10/mes (por esas 3.3 horas extra)

ROI: Positivo
```

---

### "¿Funciona con librerías que usan reflection?"

**Respuesta:**
> "La mayoría sí, pero requieren configuración. Quarkus automatiza esto para las librerías más comunes (Hibernate, Jackson, etc.). Para librerías custom, necesitas generar reflect-config.json."

**Demo rápida:**
```bash
# Quarkus genera esto automáticamente
cat target/quarkus-app/quarkus/generated-bytecode.jar
```

---

### "¿Qué pasa si necesito debugging en Native?"

**Respuesta:**
> "El debugging en Native es limitado. Por eso la estrategia es: desarrolla en JVM (debugging completo), deploya en Native (producción optimizada). Lo mejor de ambos mundos."

---

### "¿Puedo usar Native en Windows?"

**Respuesta:**
> "Sí, pero necesitas GraalVM instalado o usar Docker para compilar. En macOS ARM64 hay que compilar local o el binario no funcionará. En Linux es más directo. Por eso CI/CD con contenedores es la mejor práctica."

---

### "¿Cuánta mejora real hay en producción?"

**Respuesta (con datos):**
> "Tengo ejemplos reales:
> - Vodafone: 60% reducción de costos cloud con Quarkus Native
> - Amazon: Usa Quarkus Native para Lambdas (arranque crítico)
> - Red Hat: Propio OpenShift usa componentes en Quarkus Native
> - Los ahorros reportados van de 40-70% en costos de infraestructura."

---

## 💡 Tips de Presentación

### Energía y Ritmo

**✅ Mantener energía alta:**
- Habla con entusiasmo (esto es cool!)
- Movimiento (no te quedes pegado al teclado)
- Contacto visual con la audiencia
- Preguntas retóricas ("¿Cuánto creen que se demora?")

**⏱️ Manejo del tiempo:**
```
0-15 min:  Alta energía (intro entusiasta)
15-45 min: Ritmo sostenido (demos prácticas)
45-60 min: Pausa o mini-break
60-90 min: Ritmo moderado (teoría más densa)
90+ min:   Interactividad (Q&A, ejercicios)
```

### Técnicas de Engagement

**1. Pregunta Retórica:**
> "¿Qué preferirías: pagar $500/mes o $150/mes por la misma infraestructura? 🤔"

**2. Shock Value:**
> "Esta aplicación arranca en 0.03 segundos. Sí, CERO PUNTO CERO TRES." ⚡

**3. Comparación Tangible:**
> "Spring Boot tarda lo que demoras en hacer café. Quarkus Native tarda lo que demoras en parpadear." ☕ vs 👁️

**4. Storytelling:**
> "Imagina que eres el CTO de un banco. Tienes 50 microservicios. Con JVM: gastas $25,000/mes en cloud. Con Native: $8,000/mes. ¿Qué le dirías al CEO? 💰"

### Uso de Analogías

| Concepto | Analogía |
|----------|----------|
| Dev Services | "Asistente mágico que prepara tu escritorio" |
| JVM | "Intérprete simultáneo (flexible pero lento)" |
| Native | "Libro pre-traducido (rápido pero fijo)" |
| GraalVM AOT | "Preparar comida el domingo para toda la semana" |
| Tree Shaking | "Marie Kondo eliminando lo que no usas" |
| Docker | "Contenedor de comida (misma comida, cualquier refrigerador)" |

---

## 🏋️ Ejercicios Opcionales

### Ejercicio 1: Agregar nuevo endpoint (15 min)

**Objetivo:** Que practiquen el ciclo de desarrollo.

**Instrucciones:**
```java
// Agregar este endpoint
@GET
@Path("/top-clientes")
public List<SolicitudCredito> topClientes() {
    return SolicitudCredito.find("estado = ?1", EstadoSolicitud.APROBADO)
        .sort("montoAprobado", Sort.Direction.Descending)
        .page(Page.of(0, 5))
        .list();
}
```

**Verificación:**
```bash
curl http://localhost:8080/api/preaprobacion/top-clientes
```

---

### Ejercicio 2: Modificar regla de negocio (20 min)

**Objetivo:** Entender la lógica de scoring.

**Instrucciones:**
```
Cambiar ScoreCalculator para que:
- Antiguedad laboral > 10 años: +100 puntos extra
- Edad > 50 años: -50 puntos

Recompilar y probar.
```

---

### Ejercicio 3: Agregar nueva métrica (15 min)

**Objetivo:** Integrar métricas custom.

**Instrucciones:**
```java
@Inject
MeterRegistry registry;

public void evaluar() {
    Counter counter = registry.counter("solicitudes.evaluadas");
    counter.increment();
    
    // ... resto del código
}
```

---

## 📊 Evaluación Sugerida

### Evaluación Formativa (Durante la clase)

**Método: Poll rápido con Kahoot o similar**

```
Pregunta 1: ¿Qué es Dev Services?
A) Base de datos en la nube
B) Contenedores automáticos en desarrollo
C) Servicio de deployment
D) API Gateway

Respuesta correcta: B

Pregunta 2: ¿Cuál es la principal ventaja de Native?
A) Compilación más rápida
B) Menor uso de memoria
C) Más portabilidad
D) Mejor debugging

Respuesta correcta: B

Pregunta 3: ¿Cuándo usar JVM en lugar de Native?
A) Producción en cloud
B) Desarrollo local
C) AWS Lambda
D) Kubernetes

Respuesta correcta: B
```

### Evaluación Sumativa (Post-clase)

**Proyecto práctico:**

```
CHALLENGE: Sistema de Reservas de Hotel

Requisitos:
1. Crear entidad Reserva (Panache)
2. CRUD completo (REST endpoints)
3. Validaciones:
   - Check-in < Check-out
   - Máximo 30 días de reserva
   - No reservas duplicadas
4. Health check custom
5. Métricas de ocupación

Entregables:
- Código fuente (GitHub)
- README con setup
- Test report
- (Bonus) Benchmark JVM vs Native

Evaluación:
- Funcionalidad: 50%
- Código limpio: 20%
- Documentación: 20%
- Bonus Native: 10%
```

---

## 🎯 Checklist Final Pre-Clase

Imprime esto y márcalo:

```
□ PostgreSQL local detenido
□ Docker Desktop corriendo
□ Puertos 5432 y 8080 libres
□ docker-compose up ejecutado
□ PostgreSQL verificado (psql)
□ test-aprobacion.sh probado (13/13)
□ GraalVM activado (si harás Native)
□ benchmark.sh probado (o reporte guardado)
□ Terminal con fuente grande
□ Slides listos
□ README.md abierto (referencia)
□ instructor.md impreso
□ Respaldos listos (reportes pre-ejecutados)
□ emergency.sh preparado
□ Agua/café cerca 😅
```

---

## 📞 Soporte Post-Clase

**Para los alumnos:**

```
Recursos:
- GitHub del proyecto: [tu-repo]
- Canal Slack/Discord: [tu-canal]
- Office hours: [horario]
- Email: [tu-email]
```

**Template de email para dudas:**
```
Asunto: [Quarkus] Duda sobre [tema]

Hola [Nombre Profesor],

Estoy trabajando en [ejercicio/proyecto] y tengo un problema con [descripción].

Lo que intenté:
1. [Paso 1]
2. [Paso 2]

Error que obtengo:
[Copia el error]

Adjunto:
- Captura de pantalla
- application.properties
- Log completo

Gracias!
```

---

## 🎓 Mensaje Final

**Para ti como instructor:**

> Recuerda que no todo tiene que salir perfecto. Los errores son oportunidades de enseñanza. Si algo falla, respira, usa el Plan B, y sigue adelante.
>
> Lo más importante no son los scripts o el benchmark, sino que los alumnos entiendan:
> 1. Por qué Quarkus existe
> 2. Cuándo usarlo
> 3. Cómo les beneficia profesionalmente
>
> ¡Mucha suerte en tu clase! 🚀

---

**Última actualización:** 2025-10-23  
**Versión:** 1.0.0  
**Autor:** NETEC
