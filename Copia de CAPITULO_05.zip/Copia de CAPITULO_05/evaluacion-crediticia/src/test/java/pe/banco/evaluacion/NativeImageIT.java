package pe.banco.evaluacion;

import io.quarkus.test.junit.QuarkusIntegrationTest;
import pe.banco.evaluacion.recursos.CreditoRecursoTest;

@QuarkusIntegrationTest
public class NativeImageIT extends CreditoRecursoTest {
}
